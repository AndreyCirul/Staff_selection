﻿namespace Staff_selection
{
    partial class main_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exit = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.urgently = new System.Windows.Forms.CheckBox();
            this.newVacancie = new System.Windows.Forms.Button();
            this.newResume = new System.Windows.Forms.Button();
            this.showVacancies = new System.Windows.Forms.RadioButton();
            this.showResumes = new System.Windows.Forms.RadioButton();
            this.chuseTable = new System.Windows.Forms.Panel();
            this.sorting = new System.Windows.Forms.Panel();
            this.reverse5 = new System.Windows.Forms.CheckBox();
            this.sort5 = new System.Windows.Forms.ComboBox();
            this.reverse2 = new System.Windows.Forms.CheckBox();
            this.reverse1 = new System.Windows.Forms.CheckBox();
            this.reverse3 = new System.Windows.Forms.CheckBox();
            this.reverse4 = new System.Windows.Forms.CheckBox();
            this.sort4 = new System.Windows.Forms.ComboBox();
            this.sort3 = new System.Windows.Forms.ComboBox();
            this.sort2 = new System.Windows.Forms.ComboBox();
            this.sort1 = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.onlyUrgently = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.show = new System.Windows.Forms.Panel();
            this.departureShow = new System.Windows.Forms.CheckBox();
            this.flagShow = new System.Windows.Forms.CheckBox();
            this.nameShow = new System.Windows.Forms.CheckBox();
            this.moneyShow = new System.Windows.Forms.CheckBox();
            this.dateShow = new System.Windows.Forms.CheckBox();
            this.positionShow = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.whereName = new System.Windows.Forms.Panel();
            this.nameWhere = new System.Windows.Forms.TextBox();
            this.nameL2 = new System.Windows.Forms.Label();
            this.nameL = new System.Windows.Forms.Label();
            this.positionP = new System.Windows.Forms.Panel();
            this.positionWhere = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.moneyP = new System.Windows.Forms.Panel();
            this.moneyForC = new System.Windows.Forms.ComboBox();
            this.moneyCheck = new System.Windows.Forms.ComboBox();
            this.moneyWhere2 = new System.Windows.Forms.TextBox();
            this.moneyWhere1 = new System.Windows.Forms.TextBox();
            this.moneyMinOrMax = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.moneyL = new System.Windows.Forms.Label();
            this.dateP = new System.Windows.Forms.Panel();
            this.dateC1 = new System.Windows.Forms.CheckBox();
            this.dateC2 = new System.Windows.Forms.CheckBox();
            this.dateWhere2 = new System.Windows.Forms.DateTimePicker();
            this.dateWhere1 = new System.Windows.Forms.DateTimePicker();
            this.dateCheck = new System.Windows.Forms.ComboBox();
            this.dateMinOrMax = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dateL = new System.Windows.Forms.Label();
            this.creatingDateP = new System.Windows.Forms.Panel();
            this.creatingDateC1 = new System.Windows.Forms.CheckBox();
            this.creatingDateC2 = new System.Windows.Forms.CheckBox();
            this.creatingDateWhere2 = new System.Windows.Forms.DateTimePicker();
            this.creatingDateWhere1 = new System.Windows.Forms.DateTimePicker();
            this.creatingCheck = new System.Windows.Forms.ComboBox();
            this.creatingDateMinOrMax = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.FlagP = new System.Windows.Forms.Panel();
            this.flagWhere = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.chuseTable.SuspendLayout();
            this.sorting.SuspendLayout();
            this.panel3.SuspendLayout();
            this.show.SuspendLayout();
            this.whereName.SuspendLayout();
            this.positionP.SuspendLayout();
            this.moneyP.SuspendLayout();
            this.dateP.SuspendLayout();
            this.creatingDateP.SuspendLayout();
            this.FlagP.SuspendLayout();
            this.SuspendLayout();
            // 
            // exit
            // 
            this.exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.exit.Location = new System.Drawing.Point(972, 526);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 23;
            this.exit.Text = "Выход";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(645, 508);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // urgently
            // 
            this.urgently.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.urgently.AutoSize = true;
            this.urgently.Location = new System.Drawing.Point(4, 3);
            this.urgently.Name = "urgently";
            this.urgently.Size = new System.Drawing.Size(159, 17);
            this.urgently.TabIndex = 19;
            this.urgently.Text = "Сперва показать срочные";
            this.urgently.UseVisualStyleBackColor = true;
            this.urgently.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // newVacancie
            // 
            this.newVacancie.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.newVacancie.Location = new System.Drawing.Point(12, 526);
            this.newVacancie.Name = "newVacancie";
            this.newVacancie.Size = new System.Drawing.Size(123, 23);
            this.newVacancie.TabIndex = 21;
            this.newVacancie.Text = "Создать  вакансию";
            this.newVacancie.UseVisualStyleBackColor = true;
            this.newVacancie.Click += new System.EventHandler(this.newVacancie_Click);
            // 
            // newResume
            // 
            this.newResume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.newResume.Location = new System.Drawing.Point(141, 526);
            this.newResume.Name = "newResume";
            this.newResume.Size = new System.Drawing.Size(116, 23);
            this.newResume.TabIndex = 22;
            this.newResume.Text = "Создать резюме";
            this.newResume.UseVisualStyleBackColor = true;
            this.newResume.Click += new System.EventHandler(this.newResume_Click);
            // 
            // showVacancies
            // 
            this.showVacancies.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.showVacancies.AutoSize = true;
            this.showVacancies.Checked = true;
            this.showVacancies.Location = new System.Drawing.Point(3, 3);
            this.showVacancies.Name = "showVacancies";
            this.showVacancies.Size = new System.Drawing.Size(74, 17);
            this.showVacancies.TabIndex = 1;
            this.showVacancies.TabStop = true;
            this.showVacancies.Text = "Вакансии";
            this.showVacancies.UseVisualStyleBackColor = true;
            this.showVacancies.CheckedChanged += new System.EventHandler(this.showVacancies_CheckedChanged);
            // 
            // showResumes
            // 
            this.showResumes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.showResumes.AutoSize = true;
            this.showResumes.Location = new System.Drawing.Point(104, 3);
            this.showResumes.Name = "showResumes";
            this.showResumes.Size = new System.Drawing.Size(66, 17);
            this.showResumes.TabIndex = 2;
            this.showResumes.Text = "Резюме";
            this.showResumes.UseVisualStyleBackColor = true;
            this.showResumes.CheckedChanged += new System.EventHandler(this.showResumes_CheckedChanged);
            // 
            // chuseTable
            // 
            this.chuseTable.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chuseTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chuseTable.Controls.Add(this.showResumes);
            this.chuseTable.Controls.Add(this.showVacancies);
            this.chuseTable.Location = new System.Drawing.Point(665, 30);
            this.chuseTable.Name = "chuseTable";
            this.chuseTable.Size = new System.Drawing.Size(175, 25);
            this.chuseTable.TabIndex = 8;
            // 
            // sorting
            // 
            this.sorting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sorting.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sorting.Controls.Add(this.reverse5);
            this.sorting.Controls.Add(this.sort5);
            this.sorting.Controls.Add(this.reverse2);
            this.sorting.Controls.Add(this.reverse1);
            this.sorting.Controls.Add(this.reverse3);
            this.sorting.Controls.Add(this.reverse4);
            this.sorting.Controls.Add(this.sort4);
            this.sorting.Controls.Add(this.sort3);
            this.sorting.Controls.Add(this.sort2);
            this.sorting.Controls.Add(this.sort1);
            this.sorting.Location = new System.Drawing.Point(665, 236);
            this.sorting.Name = "sorting";
            this.sorting.Size = new System.Drawing.Size(176, 256);
            this.sorting.TabIndex = 9;
            // 
            // reverse5
            // 
            this.reverse5.AutoSize = true;
            this.reverse5.Location = new System.Drawing.Point(4, 231);
            this.reverse5.Name = "reverse5";
            this.reverse5.Size = new System.Drawing.Size(130, 17);
            this.reverse5.TabIndex = 18;
            this.reverse5.Text = "В обратном порядке";
            this.reverse5.UseVisualStyleBackColor = true;
            this.reverse5.Visible = false;
            // 
            // sort5
            // 
            this.sort5.FormattingEnabled = true;
            this.sort5.Location = new System.Drawing.Point(4, 204);
            this.sort5.Name = "sort5";
            this.sort5.Size = new System.Drawing.Size(159, 21);
            this.sort5.TabIndex = 17;
            this.sort5.Visible = false;
            // 
            // reverse2
            // 
            this.reverse2.AutoSize = true;
            this.reverse2.Location = new System.Drawing.Point(5, 81);
            this.reverse2.Name = "reverse2";
            this.reverse2.Size = new System.Drawing.Size(130, 17);
            this.reverse2.TabIndex = 12;
            this.reverse2.Text = "В обратном порядке";
            this.reverse2.UseVisualStyleBackColor = true;
            this.reverse2.Visible = false;
            this.reverse2.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // reverse1
            // 
            this.reverse1.AutoSize = true;
            this.reverse1.Location = new System.Drawing.Point(5, 31);
            this.reverse1.Name = "reverse1";
            this.reverse1.Size = new System.Drawing.Size(130, 17);
            this.reverse1.TabIndex = 10;
            this.reverse1.Text = "В обратном порядке";
            this.reverse1.UseVisualStyleBackColor = true;
            this.reverse1.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // reverse3
            // 
            this.reverse3.AutoSize = true;
            this.reverse3.Location = new System.Drawing.Point(5, 131);
            this.reverse3.Name = "reverse3";
            this.reverse3.Size = new System.Drawing.Size(130, 17);
            this.reverse3.TabIndex = 14;
            this.reverse3.Text = "В обратном порядке";
            this.reverse3.UseVisualStyleBackColor = true;
            this.reverse3.Visible = false;
            this.reverse3.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // reverse4
            // 
            this.reverse4.AutoSize = true;
            this.reverse4.Location = new System.Drawing.Point(5, 181);
            this.reverse4.Name = "reverse4";
            this.reverse4.Size = new System.Drawing.Size(130, 17);
            this.reverse4.TabIndex = 16;
            this.reverse4.Text = "В обратном порядке";
            this.reverse4.UseVisualStyleBackColor = true;
            this.reverse4.Visible = false;
            this.reverse4.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // sort4
            // 
            this.sort4.FormattingEnabled = true;
            this.sort4.Location = new System.Drawing.Point(5, 154);
            this.sort4.Name = "sort4";
            this.sort4.Size = new System.Drawing.Size(158, 21);
            this.sort4.TabIndex = 15;
            this.sort4.Visible = false;
            this.sort4.SelectedIndexChanged += new System.EventHandler(this.sort_SelectedIndexChanged);
            // 
            // sort3
            // 
            this.sort3.FormattingEnabled = true;
            this.sort3.Location = new System.Drawing.Point(5, 104);
            this.sort3.Name = "sort3";
            this.sort3.Size = new System.Drawing.Size(158, 21);
            this.sort3.TabIndex = 13;
            this.sort3.Visible = false;
            this.sort3.SelectedIndexChanged += new System.EventHandler(this.sort_SelectedIndexChanged);
            // 
            // sort2
            // 
            this.sort2.FormattingEnabled = true;
            this.sort2.Location = new System.Drawing.Point(5, 54);
            this.sort2.Name = "sort2";
            this.sort2.Size = new System.Drawing.Size(158, 21);
            this.sort2.TabIndex = 11;
            this.sort2.Visible = false;
            this.sort2.SelectedIndexChanged += new System.EventHandler(this.sort_SelectedIndexChanged);
            // 
            // sort1
            // 
            this.sort1.FormattingEnabled = true;
            this.sort1.Items.AddRange(new object[] {
            "",
            "Работодатель",
            "Должность",
            "Зарплата",
            "Дата отправки",
            "Дата создания заявки",
            "Флаг судна"});
            this.sort1.Location = new System.Drawing.Point(5, 4);
            this.sort1.Name = "sort1";
            this.sort1.Size = new System.Drawing.Size(158, 21);
            this.sort1.TabIndex = 9;
            this.sort1.SelectedIndexChanged += new System.EventHandler(this.sort_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.onlyUrgently);
            this.panel3.Controls.Add(this.urgently);
            this.panel3.Location = new System.Drawing.Point(664, 498);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(383, 22);
            this.panel3.TabIndex = 10;
            // 
            // onlyUrgently
            // 
            this.onlyUrgently.AutoSize = true;
            this.onlyUrgently.Location = new System.Drawing.Point(223, 3);
            this.onlyUrgently.Name = "onlyUrgently";
            this.onlyUrgently.Size = new System.Drawing.Size(159, 17);
            this.onlyUrgently.TabIndex = 20;
            this.onlyUrgently.Text = "Показать только срочные";
            this.onlyUrgently.UseVisualStyleBackColor = true;
            this.onlyUrgently.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(716, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Показать";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Location = new System.Drawing.Point(716, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Столбцы";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(716, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Сортировка";
            // 
            // show
            // 
            this.show.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.show.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.show.Controls.Add(this.departureShow);
            this.show.Controls.Add(this.flagShow);
            this.show.Controls.Add(this.nameShow);
            this.show.Controls.Add(this.moneyShow);
            this.show.Controls.Add(this.dateShow);
            this.show.Controls.Add(this.positionShow);
            this.show.Location = new System.Drawing.Point(665, 75);
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(175, 142);
            this.show.TabIndex = 14;
            // 
            // departureShow
            // 
            this.departureShow.AutoSize = true;
            this.departureShow.Checked = true;
            this.departureShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.departureShow.Location = new System.Drawing.Point(4, 73);
            this.departureShow.Name = "departureShow";
            this.departureShow.Size = new System.Drawing.Size(102, 17);
            this.departureShow.TabIndex = 7;
            this.departureShow.Text = "Дата отправки";
            this.departureShow.UseVisualStyleBackColor = true;
            this.departureShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // flagShow
            // 
            this.flagShow.AutoSize = true;
            this.flagShow.Checked = true;
            this.flagShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.flagShow.Location = new System.Drawing.Point(5, 120);
            this.flagShow.Name = "flagShow";
            this.flagShow.Size = new System.Drawing.Size(86, 17);
            this.flagShow.TabIndex = 6;
            this.flagShow.Text = "Флаг судна";
            this.flagShow.UseVisualStyleBackColor = true;
            this.flagShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // nameShow
            // 
            this.nameShow.AutoSize = true;
            this.nameShow.Checked = true;
            this.nameShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.nameShow.Location = new System.Drawing.Point(3, 4);
            this.nameShow.Name = "nameShow";
            this.nameShow.Size = new System.Drawing.Size(97, 17);
            this.nameShow.TabIndex = 3;
            this.nameShow.Text = "Работодатель";
            this.nameShow.UseVisualStyleBackColor = true;
            this.nameShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // moneyShow
            // 
            this.moneyShow.AutoSize = true;
            this.moneyShow.Checked = true;
            this.moneyShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.moneyShow.Location = new System.Drawing.Point(4, 50);
            this.moneyShow.Name = "moneyShow";
            this.moneyShow.Size = new System.Drawing.Size(74, 17);
            this.moneyShow.TabIndex = 5;
            this.moneyShow.Text = "Зарплата";
            this.moneyShow.UseVisualStyleBackColor = true;
            this.moneyShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // dateShow
            // 
            this.dateShow.AutoSize = true;
            this.dateShow.Checked = true;
            this.dateShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.dateShow.Location = new System.Drawing.Point(3, 96);
            this.dateShow.Name = "dateShow";
            this.dateShow.Size = new System.Drawing.Size(142, 17);
            this.dateShow.TabIndex = 8;
            this.dateShow.Text = "Дата создания заявки";
            this.dateShow.UseVisualStyleBackColor = true;
            this.dateShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // positionShow
            // 
            this.positionShow.AutoSize = true;
            this.positionShow.Checked = true;
            this.positionShow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.positionShow.Location = new System.Drawing.Point(3, 27);
            this.positionShow.Name = "positionShow";
            this.positionShow.Size = new System.Drawing.Size(84, 17);
            this.positionShow.TabIndex = 4;
            this.positionShow.Text = "Должность";
            this.positionShow.UseVisualStyleBackColor = true;
            this.positionShow.CheckedChanged += new System.EventHandler(this.updateDataGrided);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(920, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Фильтры";
            // 
            // whereName
            // 
            this.whereName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.whereName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.whereName.Controls.Add(this.nameWhere);
            this.whereName.Controls.Add(this.nameL2);
            this.whereName.Controls.Add(this.nameL);
            this.whereName.Location = new System.Drawing.Point(847, 29);
            this.whereName.Name = "whereName";
            this.whereName.Size = new System.Drawing.Size(200, 51);
            this.whereName.TabIndex = 25;
            // 
            // nameWhere
            // 
            this.nameWhere.Location = new System.Drawing.Point(95, 26);
            this.nameWhere.Name = "nameWhere";
            this.nameWhere.Size = new System.Drawing.Size(100, 20);
            this.nameWhere.TabIndex = 2;
            this.nameWhere.TextChanged += new System.EventHandler(this.where_Leave);
            // 
            // nameL2
            // 
            this.nameL2.AutoSize = true;
            this.nameL2.Location = new System.Drawing.Point(3, 29);
            this.nameL2.Name = "nameL2";
            this.nameL2.Size = new System.Drawing.Size(87, 13);
            this.nameL2.TabIndex = 1;
            this.nameL2.Text = "Работодатель =";
            // 
            // nameL
            // 
            this.nameL.AutoSize = true;
            this.nameL.Location = new System.Drawing.Point(61, 0);
            this.nameL.Name = "nameL";
            this.nameL.Size = new System.Drawing.Size(78, 13);
            this.nameL.TabIndex = 0;
            this.nameL.Text = "Работодатель";
            // 
            // positionP
            // 
            this.positionP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.positionP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.positionP.Controls.Add(this.positionWhere);
            this.positionP.Controls.Add(this.label6);
            this.positionP.Controls.Add(this.label5);
            this.positionP.Location = new System.Drawing.Point(847, 86);
            this.positionP.Name = "positionP";
            this.positionP.Size = new System.Drawing.Size(200, 42);
            this.positionP.TabIndex = 27;
            // 
            // positionWhere
            // 
            this.positionWhere.Location = new System.Drawing.Point(95, 16);
            this.positionWhere.Name = "positionWhere";
            this.positionWhere.Size = new System.Drawing.Size(100, 20);
            this.positionWhere.TabIndex = 2;
            this.positionWhere.TextChanged += new System.EventHandler(this.where_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Должность =";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Должность";
            // 
            // moneyP
            // 
            this.moneyP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.moneyP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.moneyP.Controls.Add(this.moneyForC);
            this.moneyP.Controls.Add(this.moneyCheck);
            this.moneyP.Controls.Add(this.moneyWhere2);
            this.moneyP.Controls.Add(this.moneyWhere1);
            this.moneyP.Controls.Add(this.moneyMinOrMax);
            this.moneyP.Controls.Add(this.label7);
            this.moneyP.Controls.Add(this.moneyL);
            this.moneyP.Location = new System.Drawing.Point(847, 134);
            this.moneyP.Name = "moneyP";
            this.moneyP.Size = new System.Drawing.Size(200, 99);
            this.moneyP.TabIndex = 28;
            // 
            // moneyForC
            // 
            this.moneyForC.FormattingEnabled = true;
            this.moneyForC.Items.AddRange(new object[] {
            "",
            "в день",
            "в месяц",
            "за рейс"});
            this.moneyForC.Location = new System.Drawing.Point(105, 69);
            this.moneyForC.Name = "moneyForC";
            this.moneyForC.Size = new System.Drawing.Size(90, 21);
            this.moneyForC.TabIndex = 7;
            this.moneyForC.SelectedIndexChanged += new System.EventHandler(this.where_Leave);
            // 
            // moneyCheck
            // 
            this.moneyCheck.FormattingEnabled = true;
            this.moneyCheck.Items.AddRange(new object[] {
            "=",
            ">",
            "<"});
            this.moneyCheck.Location = new System.Drawing.Point(56, 19);
            this.moneyCheck.Name = "moneyCheck";
            this.moneyCheck.Size = new System.Drawing.Size(43, 21);
            this.moneyCheck.TabIndex = 6;
            this.moneyCheck.SelectedIndexChanged += new System.EventHandler(this.moneyCheck_SelectedIndexChanged);
            // 
            // moneyWhere2
            // 
            this.moneyWhere2.Location = new System.Drawing.Point(104, 43);
            this.moneyWhere2.Name = "moneyWhere2";
            this.moneyWhere2.Size = new System.Drawing.Size(91, 20);
            this.moneyWhere2.TabIndex = 5;
            this.moneyWhere2.Visible = false;
            this.moneyWhere2.TextChanged += new System.EventHandler(this.where_Leave);
            this.moneyWhere2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNum);
            // 
            // moneyWhere1
            // 
            this.moneyWhere1.Location = new System.Drawing.Point(105, 19);
            this.moneyWhere1.Name = "moneyWhere1";
            this.moneyWhere1.Size = new System.Drawing.Size(90, 20);
            this.moneyWhere1.TabIndex = 4;
            this.moneyWhere1.TextChanged += new System.EventHandler(this.moneyWhere1_Leave);
            this.moneyWhere1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNum);
            // 
            // moneyMinOrMax
            // 
            this.moneyMinOrMax.AutoSize = true;
            this.moneyMinOrMax.Location = new System.Drawing.Point(66, 46);
            this.moneyMinOrMax.Name = "moneyMinOrMax";
            this.moneyMinOrMax.Size = new System.Drawing.Size(13, 13);
            this.moneyMinOrMax.TabIndex = 3;
            this.moneyMinOrMax.Text = "<";
            this.moneyMinOrMax.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Зарплата";
            // 
            // moneyL
            // 
            this.moneyL.AutoSize = true;
            this.moneyL.Location = new System.Drawing.Point(72, 0);
            this.moneyL.Name = "moneyL";
            this.moneyL.Size = new System.Drawing.Size(55, 13);
            this.moneyL.TabIndex = 0;
            this.moneyL.Text = "Зарплата";
            // 
            // dateP
            // 
            this.dateP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateP.Controls.Add(this.dateC1);
            this.dateP.Controls.Add(this.dateC2);
            this.dateP.Controls.Add(this.dateWhere2);
            this.dateP.Controls.Add(this.dateWhere1);
            this.dateP.Controls.Add(this.dateCheck);
            this.dateP.Controls.Add(this.dateMinOrMax);
            this.dateP.Controls.Add(this.label11);
            this.dateP.Controls.Add(this.dateL);
            this.dateP.Location = new System.Drawing.Point(847, 236);
            this.dateP.Name = "dateP";
            this.dateP.Size = new System.Drawing.Size(200, 67);
            this.dateP.TabIndex = 29;
            // 
            // dateC1
            // 
            this.dateC1.AutoSize = true;
            this.dateC1.Location = new System.Drawing.Point(3, 18);
            this.dateC1.Name = "dateC1";
            this.dateC1.Size = new System.Drawing.Size(15, 14);
            this.dateC1.TabIndex = 8;
            this.dateC1.UseVisualStyleBackColor = true;
            this.dateC1.CheckedChanged += new System.EventHandler(this.dateC1_CheckedChanged);
            // 
            // dateC2
            // 
            this.dateC2.AutoSize = true;
            this.dateC2.Location = new System.Drawing.Point(3, 42);
            this.dateC2.Name = "dateC2";
            this.dateC2.Size = new System.Drawing.Size(15, 14);
            this.dateC2.TabIndex = 7;
            this.dateC2.UseVisualStyleBackColor = true;
            this.dateC2.Visible = false;
            this.dateC2.CheckedChanged += new System.EventHandler(this.where_Leave);
            // 
            // dateWhere2
            // 
            this.dateWhere2.Location = new System.Drawing.Point(105, 42);
            this.dateWhere2.Name = "dateWhere2";
            this.dateWhere2.Size = new System.Drawing.Size(90, 20);
            this.dateWhere2.TabIndex = 6;
            this.dateWhere2.Visible = false;
            this.dateWhere2.ValueChanged += new System.EventHandler(this.where_Leave);
            // 
            // dateWhere1
            // 
            this.dateWhere1.Location = new System.Drawing.Point(105, 16);
            this.dateWhere1.Name = "dateWhere1";
            this.dateWhere1.Size = new System.Drawing.Size(90, 20);
            this.dateWhere1.TabIndex = 5;
            this.dateWhere1.ValueChanged += new System.EventHandler(this.where_Leave);
            // 
            // dateCheck
            // 
            this.dateCheck.FormattingEnabled = true;
            this.dateCheck.Items.AddRange(new object[] {
            "=",
            ">",
            "<"});
            this.dateCheck.Location = new System.Drawing.Point(56, 14);
            this.dateCheck.Name = "dateCheck";
            this.dateCheck.Size = new System.Drawing.Size(43, 21);
            this.dateCheck.TabIndex = 4;
            this.dateCheck.SelectedIndexChanged += new System.EventHandler(this.dateCheck_SelectedIndexChanged);
            // 
            // dateMinOrMax
            // 
            this.dateMinOrMax.AutoSize = true;
            this.dateMinOrMax.Location = new System.Drawing.Point(66, 42);
            this.dateMinOrMax.Name = "dateMinOrMax";
            this.dateMinOrMax.Size = new System.Drawing.Size(13, 13);
            this.dateMinOrMax.TabIndex = 3;
            this.dateMinOrMax.Text = "<";
            this.dateMinOrMax.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Дата";
            // 
            // dateL
            // 
            this.dateL.AutoSize = true;
            this.dateL.Location = new System.Drawing.Point(61, 0);
            this.dateL.Name = "dateL";
            this.dateL.Size = new System.Drawing.Size(85, 13);
            this.dateL.TabIndex = 0;
            this.dateL.Text = "Дата Отправки";
            this.dateL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // creatingDateP
            // 
            this.creatingDateP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.creatingDateP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.creatingDateP.Controls.Add(this.creatingDateC1);
            this.creatingDateP.Controls.Add(this.creatingDateC2);
            this.creatingDateP.Controls.Add(this.creatingDateWhere2);
            this.creatingDateP.Controls.Add(this.creatingDateWhere1);
            this.creatingDateP.Controls.Add(this.creatingCheck);
            this.creatingDateP.Controls.Add(this.creatingDateMinOrMax);
            this.creatingDateP.Controls.Add(this.label15);
            this.creatingDateP.Controls.Add(this.label8);
            this.creatingDateP.Location = new System.Drawing.Point(847, 305);
            this.creatingDateP.Name = "creatingDateP";
            this.creatingDateP.Size = new System.Drawing.Size(200, 67);
            this.creatingDateP.TabIndex = 30;
            // 
            // creatingDateC1
            // 
            this.creatingDateC1.AutoSize = true;
            this.creatingDateC1.Location = new System.Drawing.Point(3, 18);
            this.creatingDateC1.Name = "creatingDateC1";
            this.creatingDateC1.Size = new System.Drawing.Size(15, 14);
            this.creatingDateC1.TabIndex = 11;
            this.creatingDateC1.UseVisualStyleBackColor = true;
            this.creatingDateC1.CheckedChanged += new System.EventHandler(this.creatingDateC1_CheckedChanged);
            // 
            // creatingDateC2
            // 
            this.creatingDateC2.AutoSize = true;
            this.creatingDateC2.Location = new System.Drawing.Point(3, 42);
            this.creatingDateC2.Name = "creatingDateC2";
            this.creatingDateC2.Size = new System.Drawing.Size(15, 14);
            this.creatingDateC2.TabIndex = 10;
            this.creatingDateC2.UseVisualStyleBackColor = true;
            this.creatingDateC2.Visible = false;
            this.creatingDateC2.CheckedChanged += new System.EventHandler(this.where_Leave);
            // 
            // creatingDateWhere2
            // 
            this.creatingDateWhere2.Location = new System.Drawing.Point(105, 42);
            this.creatingDateWhere2.Name = "creatingDateWhere2";
            this.creatingDateWhere2.Size = new System.Drawing.Size(90, 20);
            this.creatingDateWhere2.TabIndex = 9;
            this.creatingDateWhere2.Visible = false;
            this.creatingDateWhere2.ValueChanged += new System.EventHandler(this.where_Leave);
            // 
            // creatingDateWhere1
            // 
            this.creatingDateWhere1.Location = new System.Drawing.Point(105, 16);
            this.creatingDateWhere1.Name = "creatingDateWhere1";
            this.creatingDateWhere1.Size = new System.Drawing.Size(90, 20);
            this.creatingDateWhere1.TabIndex = 8;
            this.creatingDateWhere1.ValueChanged += new System.EventHandler(this.where_Leave);
            // 
            // creatingCheck
            // 
            this.creatingCheck.FormattingEnabled = true;
            this.creatingCheck.Items.AddRange(new object[] {
            "=",
            ">",
            "<"});
            this.creatingCheck.Location = new System.Drawing.Point(56, 16);
            this.creatingCheck.Name = "creatingCheck";
            this.creatingCheck.Size = new System.Drawing.Size(43, 21);
            this.creatingCheck.TabIndex = 7;
            this.creatingCheck.SelectedIndexChanged += new System.EventHandler(this.creatingCheck_SelectedIndexChanged);
            // 
            // creatingDateMinOrMax
            // 
            this.creatingDateMinOrMax.AutoSize = true;
            this.creatingDateMinOrMax.Location = new System.Drawing.Point(66, 42);
            this.creatingDateMinOrMax.Name = "creatingDateMinOrMax";
            this.creatingDateMinOrMax.Size = new System.Drawing.Size(13, 13);
            this.creatingDateMinOrMax.TabIndex = 6;
            this.creatingDateMinOrMax.Text = "<";
            this.creatingDateMinOrMax.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(20, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Дата";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Дата создания заявки";
            // 
            // FlagP
            // 
            this.FlagP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FlagP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FlagP.Controls.Add(this.flagWhere);
            this.FlagP.Controls.Add(this.label16);
            this.FlagP.Controls.Add(this.label9);
            this.FlagP.Location = new System.Drawing.Point(847, 374);
            this.FlagP.Name = "FlagP";
            this.FlagP.Size = new System.Drawing.Size(200, 44);
            this.FlagP.TabIndex = 31;
            // 
            // flagWhere
            // 
            this.flagWhere.Location = new System.Drawing.Point(56, 17);
            this.flagWhere.Name = "flagWhere";
            this.flagWhere.Size = new System.Drawing.Size(138, 20);
            this.flagWhere.TabIndex = 2;
            this.flagWhere.TextChanged += new System.EventHandler(this.where_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Флаг =";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(72, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Флаг судна";
            // 
            // main_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 554);
            this.Controls.Add(this.FlagP);
            this.Controls.Add(this.creatingDateP);
            this.Controls.Add(this.dateP);
            this.Controls.Add(this.moneyP);
            this.Controls.Add(this.positionP);
            this.Controls.Add(this.whereName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.show);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.sorting);
            this.Controls.Add(this.chuseTable);
            this.Controls.Add(this.newResume);
            this.Controls.Add(this.newVacancie);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.exit);
            this.MinimumSize = new System.Drawing.Size(768, 592);
            this.Name = "main_menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главное меню";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_menu_FormClosing);
            this.EnabledChanged += new System.EventHandler(this.updateDataGrided);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.chuseTable.ResumeLayout(false);
            this.chuseTable.PerformLayout();
            this.sorting.ResumeLayout(false);
            this.sorting.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.show.ResumeLayout(false);
            this.show.PerformLayout();
            this.whereName.ResumeLayout(false);
            this.whereName.PerformLayout();
            this.positionP.ResumeLayout(false);
            this.positionP.PerformLayout();
            this.moneyP.ResumeLayout(false);
            this.moneyP.PerformLayout();
            this.dateP.ResumeLayout(false);
            this.dateP.PerformLayout();
            this.creatingDateP.ResumeLayout(false);
            this.creatingDateP.PerformLayout();
            this.FlagP.ResumeLayout(false);
            this.FlagP.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox urgently;
        private System.Windows.Forms.Button newVacancie;
        private System.Windows.Forms.Button newResume;
        private System.Windows.Forms.RadioButton showVacancies;
        private System.Windows.Forms.RadioButton showResumes;
        private System.Windows.Forms.Panel chuseTable;
        private System.Windows.Forms.Panel sorting;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox reverse2;
        private System.Windows.Forms.CheckBox reverse1;
        private System.Windows.Forms.CheckBox reverse3;
        private System.Windows.Forms.CheckBox reverse4;
        private System.Windows.Forms.ComboBox sort4;
        private System.Windows.Forms.ComboBox sort3;
        private System.Windows.Forms.ComboBox sort2;
        private System.Windows.Forms.ComboBox sort1;
        private System.Windows.Forms.CheckBox onlyUrgently;
        private System.Windows.Forms.Panel show;
        private System.Windows.Forms.CheckBox flagShow;
        private System.Windows.Forms.CheckBox nameShow;
        private System.Windows.Forms.CheckBox moneyShow;
        private System.Windows.Forms.CheckBox dateShow;
        private System.Windows.Forms.CheckBox positionShow;
        private System.Windows.Forms.CheckBox reverse5;
        private System.Windows.Forms.ComboBox sort5;
        private System.Windows.Forms.CheckBox departureShow;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel whereName;
        private System.Windows.Forms.Label nameL;
        private System.Windows.Forms.TextBox nameWhere;
        private System.Windows.Forms.Label nameL2;
        private System.Windows.Forms.Panel positionP;
        private System.Windows.Forms.TextBox positionWhere;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel moneyP;
        private System.Windows.Forms.ComboBox moneyCheck;
        private System.Windows.Forms.TextBox moneyWhere2;
        private System.Windows.Forms.TextBox moneyWhere1;
        private System.Windows.Forms.Label moneyMinOrMax;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label moneyL;
        private System.Windows.Forms.Panel dateP;
        private System.Windows.Forms.Label dateMinOrMax;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label dateL;
        private System.Windows.Forms.Panel creatingDateP;
        private System.Windows.Forms.Label creatingDateMinOrMax;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel FlagP;
        private System.Windows.Forms.TextBox flagWhere;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateWhere2;
        private System.Windows.Forms.DateTimePicker dateWhere1;
        private System.Windows.Forms.ComboBox dateCheck;
        private System.Windows.Forms.DateTimePicker creatingDateWhere2;
        private System.Windows.Forms.DateTimePicker creatingDateWhere1;
        private System.Windows.Forms.ComboBox creatingCheck;
        private System.Windows.Forms.CheckBox dateC1;
        private System.Windows.Forms.CheckBox dateC2;
        private System.Windows.Forms.CheckBox creatingDateC1;
        private System.Windows.Forms.CheckBox creatingDateC2;
        private System.Windows.Forms.ComboBox moneyForC;
    }
}