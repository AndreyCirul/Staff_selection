﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Staff_selection
{
    public partial class main_menu : Form
    {
        private string showing = "vacancies";
        private ComboBox[] sorts = new ComboBox[5];
        private CheckBox[] reveres = new CheckBox[5];
        private CheckBox[] showCollums = new CheckBox[6];
        private bool closedByButtom = false;
        private DataTable dt = new DataTable();
        private bool change=false;

        public main_menu()
        {
            InitializeComponent();
            change = true;
            //добавление элементов сортировки
            sorts[0] = sort1;
            sorts[1] = sort2;
            sorts[2] = sort3;
            sorts[3] = sort4;
            sorts[4] = sort5;

            //составление списка обратного порядка сортировки
            reveres[0] = reverse1;
            reveres[1] = reverse2;
            reveres[2] = reverse3;
            reveres[3] = reverse4;
            reveres[4] = reverse5;

            //составление списка строк которые будут выводиться
            showCollums[0] = nameShow;
            showCollums[1] = positionShow;
            showCollums[2] = moneyShow; 
            showCollums[3] = departureShow;
            showCollums[4] = dateShow;
            showCollums[5] = flagShow;

            //задает стартовые значения для ComboBox в фильтрах
            moneyCheck.SelectedIndex = 0;
            dateCheck.SelectedIndex = 0;
            creatingCheck.SelectedIndex = 0;
            moneyForC.SelectedIndex = 0;
            change = false;

            fillDAtaGrid();
        }

        //если окно было закрыто проверяет что оно было закрыто с кнопки и если нет то закрывает окно login после чего программа завершаеться
        private void main_menu_FormClosing(object sender, FormClosingEventArgs e)
        {
            //если закрытие окна было не из за кнопки то закрывает скрытое окно входа для закрытия программы
            if (!closedByButtom)
            {
                Form login = Application.OpenForms["login"];
                login.Close();
            }
        }

        //выход с текущего пользователя
        private void exit_Click(object sender, EventArgs e)
        {
            closedByButtom = true;
            Form login = Application.OpenForms["login"];
            login.Show();
            this.Close();
        }

        //вывод таблицы с вакансиями
        private void showVacancies_CheckedChanged(object sender, EventArgs e)
        {
            if (showVacancies.Checked == true)
            {
                change = true;
                showing = "vacancies";
                sort1.Items[1] = "Работодатель";
                showCollums[0].Text = "Работодатель";
                sort1.Items[3] = "Зарплата";
                showCollums[2].Text = "Зарплата";
                sort1.Items[4] = "Дата отправки";
                showCollums[3].Text = "Дата отправки";
                sort1.Items.Add("Флаг судна");
                nameL.Text = "Работодатель";
                nameL2.Text = "Работодатель =";
                moneyL.Text = "Зарплата";
                dateL.Text = "Дата отправки";
                FlagP.Show();
                urgently.Checked = false;
                onlyUrgently.Checked = false;
                flagShow.Show();
                for (int i = 0; i < showCollums.Length; i++)
                    showCollums[i].Checked = true;
                sort1.SelectedIndex = 0;
                clearFilters();

                fillDAtaGrid();
                change = false;
            }
        }

        //вывод таблицы с резюме
        private void showResumes_CheckedChanged(object sender, EventArgs e)
        {
            if (showResumes.Checked == true)
            {
                change = true;
                flagShow.Hide();
                showing = "resume";
                sort1.Items[1] = "ФИО";
                showCollums[0].Text = "ФИО";
                sort1.Items[3] = "Минимальная зарплата";
                showCollums[2].Text = "Минимальная зарплата";
                sort1.Items[4] = "Готовность";
                showCollums[3].Text = "Готовность";
                showCollums[5].Hide();
                showCollums[5].Checked = false;
                sort1.Items.RemoveAt(sort1.Items.IndexOf("Флаг судна"));
                urgently.Checked = false;
                onlyUrgently.Checked = false;
                nameL.Text = "ФИО";
                nameL2.Text = "ФИО =";
                moneyL.Text = "Минимальная зарплата";
                dateL.Text = "Готовность";
                FlagP.Hide();
                for (int i = 0; i < showCollums.Length; i++)
                    showCollums[i].Checked = true;
                flagShow.Checked = false;
                sort1.SelectedIndex = 0;
                clearFilters();
                fillDAtaGrid();
                change = false;
            }
        }

        //функция очистки фильтров
        private void clearFilters()
        {
            moneyCheck.SelectedIndex = 0;
            dateCheck.SelectedIndex = 0;
            creatingCheck.SelectedIndex = 0;
            moneyForC.SelectedIndex = 0;
            flagWhere.Text = "";
            nameWhere.Text = "";
            positionWhere.Text = "";
            moneyWhere1.Text = "";
            moneyWhere2.Text = "";
            dateC1.Checked = false;
            dateC2.Checked = false;
            creatingDateC1.Checked = false;
            creatingDateC2.Checked = false;
            dateWhere1.Value = DateTime.Today;
            dateWhere2.Value = DateTime.Today;
            creatingDateWhere1.Value = DateTime.Today;
            creatingDateWhere1.Value = DateTime.Today;
        }

        //отобразить или убрать поля для сортировки после измененого
        private void sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            int current=0;
            for (int i =0;i<5;i++)
            {
                if (sorts[i]==sender)
                {
                    current = i;
                    break;
                }
            }
            if (sorts[current].SelectedItem.ToString()!="")
            {
                if (current!=3)
                {
                    sorts[current + 1].Visible = true;
                    reveres[current + 1].Visible = true;
                    for (int j = 0; j < sorts[current].Items.Count; j++)
                    {
                        if (sorts[current].Items[j] != sorts[current].SelectedItem)
                            sorts[current + 1].Items.Add(sorts[current].Items[j]);
                    }
                }
            }
            else
            {
                for (int i =current+1;i<5;i++)
                {
                    if (sorts[i].Visible == true)
                    {
                        for (int j = sorts[i].Items.Count - 1; j >= 0; j--)
                        {
                            sorts[i].Items.RemoveAt(j);
                        }
                        sorts[i].Visible = false;
                        reveres[i].Visible = false;
                    }
                }
            }

            fillDAtaGrid();
        }

        //функция вывода таблицы
        private void fillDAtaGrid()
        {
            string where = "";
            string select = "";
            string sort = "";
            SqlConnection con = new SqlConnection();
            SqlDataAdapter da;
            DataSet ds;

            //составление списка колонок которые будут выводить
            for (int i=0;i<showCollums.Length;i++)
            {
                if (showCollums[i].Checked == true)
                {
                    if (select != "")
                        select += ", ";
                    if (showCollums[i].Text == "Зарплата")
                        select += "Зарплата, \"Зарплата в\"";
                    else
                        if (showCollums[i].Text == "Флаг судна")
                        select += "\"Флаг судна\"";
                    else
                        if (showCollums[i].Text == "Дата отправки")
                        select += "\"Дата отправки\"";
                    else
                         if (showCollums[i].Text == "Минимальная зарплата")
                        select += "\"Минимальная зарплата\", \"Зарплата в\"";
                    else
                        if (showCollums[i].Text == "Дата создания заявки")
                        select += "\"Дата создания заявки\"";
                    else
                        select += showCollums[i].Text;
                }
            }

            //выводит срочные записи первыми
            if(urgently.Checked==true)
            {
                sort += " ORDER BY Срочная DESC";
            }

            //составление списка колонок по которым будет выполнена сортировка
            for (int i=0;i<sorts.Length;i++)
            {
                if (sorts[i].SelectedItem != null)
                {
                    if (sorts[i].SelectedItem.ToString() != "")
                    {
                        if (sort == "")
                        {
                            sort += " ORDER BY ";
                            if (sorts[i].SelectedItem.ToString() == "Флаг судна")
                                sort += "\"Флаг судна\"";
                            else                           
                                if (sorts[i].SelectedItem.ToString() == "Флаг судна")
                                    sort += "\"Флаг судна\"";
                                else
                                    if (sorts[i].SelectedItem.ToString() == "Дата отправки")
                                        sort += "\"Дата отправки\"";
                                    else     
                                        if (sorts[i].SelectedItem.ToString() == "Минимальная зарплата")
                                            sort += "\"Зарплата в\", \"Минимальная зарплата\"";
                                        else  
                                            if (sorts[i].SelectedItem.ToString() == "Зарплата")
                                                sort += "\"Зарплата в\", Зарплата";
                                            else
                                                if (sorts[i].SelectedItem.ToString() == "Дата создания заявки")
                                                    sort += "\"Дата создания заявки\"";
                                                else
                                                    sort += sorts[i].SelectedItem.ToString();
                            if (reveres[i].Checked == true)
                                sort += " DESC";
                        }
                        else
                        {
                            sort += ", ";
                            if (sorts[i].SelectedItem.ToString() == "Флаг судна")
                                sort += "\"Флаг судна\"";
                            else
                                if (sorts[i].SelectedItem.ToString() == "Флаг судна")
                                    sort += "\"Флаг судна\"";
                                else
                                    if (sorts[i].SelectedItem.ToString() == "Дата отправки")
                                        sort += "\"Дата отправки\"";
                                    else
                                        if (sorts[i].SelectedItem.ToString() == "Минимальная зарплата")
                                            sort += "\"Зарплата в\", \"Минимальная зарплата\"";
                                        else
                                            if (sorts[i].SelectedItem.ToString() == "Зарплата")
                                                sort += "\"Зарплата в\", Зарплата";
                                            else
                                                if (sorts[i].SelectedItem.ToString() == "Дата создания заявки")
                                                    sort += "\"Дата создания заявки\"";
                                                else
                                                    sort += sorts[i].SelectedItem.ToString();                    
                            if (reveres[i].Checked == true)
                                sort += " DESC";
                        }
                    }
                    else
                        break;
                }
                else
                    break;
            }

            //выводит только срочные записи
            if(onlyUrgently.Checked==true)
            {
                where = " WHERE (Срочная=1)";
            }

            //построение where для запроса
            if (nameWhere.Text!="")
            {
                if (where == "")
                    where += " WHERE (" + nameL.Text+ "=\'" + nameWhere.Text+ "\')";
                else
                    where += " AND (" + nameL.Text + "=\'" + nameWhere.Text + "\')";
            }
            if (positionWhere.Text != "")
            {
                if (where == "")
                    where += " WHERE (Должность=\'" + positionWhere.Text + "\')";
                else
                    where += " AND ( Должность=\'" + positionWhere.Text + "\')";
            }
            if (moneyWhere1.Text != "")
            {
                if (where == "")
                    where += " WHERE (\"" + moneyL.Text + "\"" + moneyCheck.SelectedItem.ToString() + moneyWhere1.Text + ")";
                else
                    where += " AND (\"" + moneyL.Text + "\"" + moneyCheck.SelectedItem.ToString() + moneyWhere1.Text + ")";
            }
            if (moneyWhere2.Text != "")
            {
                where += " AND (\"" + moneyL.Text + "\"" + moneyMinOrMax.Text + moneyWhere2.Text + ")";
            }
            if (moneyForC.SelectedIndex!=0 && moneyForC.SelectedIndex != -1)
            {
                if (where == "")
                    where += " WHERE (\"Зарплата в\"=\'" + moneyForC.SelectedItem.ToString() + "\')";
                else
                    where += " AND (\"Зарплата в\"=\'" + moneyForC.SelectedItem.ToString() + "\')";
            }
            if (dateC1.Checked==true)
            {
                if (where == "")
                    where += " WHERE (\"" + dateL.Text + "\"" + dateCheck.SelectedItem.ToString() + "convert(date, \'" + dateWhere1.Value.ToString("dd.MM.yyyy") + "\',105))";
                else
                    where += " AND (\"" + dateL.Text + "\"" + dateCheck.SelectedItem.ToString() + "convert(date, \'" + dateWhere1.Value.ToString("dd.MM.yyyy") + "\',105))";
            }
            if (dateC2.Checked == true)
            {
                where += " AND (\"" + dateL.Text + "\"" + dateMinOrMax.Text + "convert(date, \'" + dateWhere2.Value.ToString("dd.MM.yyyy") + "\',105))";
            }
            if (creatingDateC1.Checked == true)
            {
                if (where == "")
                    where += " WHERE (\"Дата создания заявки\"" + creatingCheck.SelectedItem.ToString() + "convert(date, \'" + creatingDateWhere1.Value.ToString("dd.MM.yyyy") + "\',105))";
                else
                    where += " AND (\"Дата создания заявки\"" + creatingCheck.SelectedItem.ToString() + "convert(date, \'" + creatingDateWhere1.Value.ToString("dd.MM.yyyy") + "\',105))";
            }
            if (creatingDateC2.Checked == true)
            {
                where += " AND (\"Дата создания заявки\"" + creatingDateMinOrMax.Text + " convert(date, \'" + creatingDateWhere2.Value.ToString("dd.MM.yyyy") + "\',105))";
            }
            if (flagWhere.Text != "")
            {
                if (where == "")
                    where += " WHERE (\"Флаг судна\"=\'" + flagWhere.Text + "\')";
                else
                    where += " AND (\"Флаг Судна \"=\'" + flagWhere.Text + "\')";
            }

                //составление запроса и ввывод таблицу
                dataGridView1.DataSource = null;
            if (select != "")
            {
                try
                {
                    con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                    con.Open(); //подключение к базе данных                    
                    da = new SqlDataAdapter("select " + select + " from " + showing + where + sort.ToString(), con); //вывод всей информации из базы для дальнейшей работы с ней
                    ds = new DataSet();
                    da.Fill(ds, "0"); //перемещение инофрмацции из базы dataset для работы с ней
                    dataGridView1.DataSource = ds.Tables[0];//вывод таблицы

                    dataGridView1.RowsDefaultCellStyle = dataGridView1.ColumnHeadersDefaultCellStyle; //Копирование стиля заголовков столбцов в заголовок строк(по умолчаниею пустой)
                    for (int i = 0; i < dataGridView1.Rows.Count; i++) //добавление нумерации строк в заголловках
                    {
                        dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                    }

                    for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        dataGridView1.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;

                    con.Close();

                   
                    con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                    con.Open(); //подключение к базе данных
                    da = new SqlDataAdapter("select Id from " + showing + where + sort, con); //вывод всей информации из базы для дальнейшей работы с ней
                    ds = new DataSet();
                    da.Fill(ds, "0");
                    dt = ds.Tables[0];
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            
        }

        //создание новой вакансией
        private void newVacancie_Click(object sender, EventArgs e)
        {
            addNew add = new addNew();
            add.table ="vacancies";
            add.Text = "Новая вакансия";
            add.move.Location = new Point(0, 275);
            add.MaximumSize = new Size(350, 708);
            add.Show();
            this.Enabled = false;
        }

        //создание нового резюме
        private void newResume_Click(object sender, EventArgs e)
        {
            addNew add = new addNew();
            add.table = "resume";
            add.Text = "Новое резюме";
            add.nameL.Text = "ФИО";
            add.dateL.Text = "Готовность";
            add.flagP.Hide();
            add.resume.Show();
            add.month.Hide();
            add.duration.Hide();
            add.durationL.Hide();
            add.Show();
            this.Enabled = false;
        }

        //обновление выведеной таблицы если были изменены какие либо параметры
        private void updateDataGrided(object sender, EventArgs e)
        {
            if (!change)
                fillDAtaGrid();
        }

        //выводит подробную информацию записи
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell != null)
            {
                details details = new details();
                details.id=dt.Rows[dataGridView1.CurrentCell.RowIndex][0].ToString();
                details.table = showing;
                if (showing=="resume")
                {
                    details.resumeTable.Show();
                    details.vacTable.Show();
                }
                details.Show();
                this.Enabled = false;
            }
        }

        //показывает/прячет элементы если был изменен знак сравнения в фильтре по зарплате
        private void moneyCheck_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(moneyCheck.SelectedItem.ToString()=="=")
            {
                moneyMinOrMax.Hide();
                moneyWhere2.Hide();
                moneyWhere2.Text = "";
            }
            if (moneyCheck.SelectedItem.ToString() == "<")
            {
                moneyMinOrMax.Text = ">";
                if (moneyWhere1.Text != "")
                {
                    moneyMinOrMax.Show();
                    moneyWhere2.Show();
                }
            }
            if (moneyCheck.SelectedItem.ToString() == ">")
            {
                moneyMinOrMax.Text = "<";
                if (moneyWhere1.Text != "")
                {
                    moneyMinOrMax.Show();
                    moneyWhere2.Show();
                }
            }
            if (!change)
                fillDAtaGrid();
        }

        //показывает/прячет элементы если был изменен знак сравнения в фильтре по дате отправки/готовности
        private void dateCheck_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dateCheck.SelectedItem.ToString() == "=")
            {
                dateMinOrMax.Hide();
                dateWhere2.Hide();
                dateC2.Hide();
                dateWhere2.Text = "";
            }
            if (dateCheck.SelectedItem.ToString() == "<")
            {
                moneyMinOrMax.Text = ">";
                    if (dateC1.Checked == true)
                    {
                        dateC2.Show();
                        dateMinOrMax.Show();
                        dateWhere2.Show();
                    }
            }
            if (dateCheck.SelectedItem.ToString() == ">")
            {
                dateMinOrMax.Text = "<";
                if (dateC1.Checked==true)
                {
                    dateC2.Show();
                    dateMinOrMax.Show();
                    dateWhere2.Show();
                }
            }
            if (!change)
                fillDAtaGrid();
        }

        //показывает/прячет элементы если был изменен знак сравнения в фильтре по дате создания
        private void creatingCheck_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (creatingCheck.SelectedItem.ToString() == "=")
            {
                creatingDateC2.Hide();
                creatingDateMinOrMax.Hide();
                creatingDateWhere2.Hide();
                creatingDateWhere2.Text = "";
            }
            if (creatingCheck.SelectedItem.ToString() == "<")
            {
                if (creatingDateC1.Checked == true)
                {
                    creatingDateC2.Show();
                    creatingDateMinOrMax.Text = ">";
                    creatingDateMinOrMax.Show();
                    creatingDateWhere2.Show();
                }
            }
            if (creatingCheck.SelectedItem.ToString() == ">")
            {
                if (creatingDateC1.Checked == true)
                {
                    creatingDateC2.Show();
                    creatingDateMinOrMax.Text = "<";
                    creatingDateMinOrMax.Show();
                    creatingDateWhere2.Show();
                }
            }
            if (!change)
                fillDAtaGrid();
        }

        ////показывает/прячет элементы если было заполнено или очищено поле фильтра по зарплате
        private void moneyWhere1_Leave(object sender, EventArgs e)
        {
            if (moneyWhere1.Text!="" && moneyCheck.SelectedItem.ToString()!="=")
            {
                moneyMinOrMax.Show();
                moneyWhere2.Show();
            }
            else
            {
                moneyMinOrMax.Hide();
                moneyWhere2.Hide();
            }

            if(change==false)
                fillDAtaGrid();
        }

        //обновляет таблицу после изменений в фильтрах
        private void where_Leave(object sender, EventArgs e)
        {
            if (change == false)
                fillDAtaGrid();
        }

        //позволяет вводить только цифры в поля фильтра зарплаты
        private void onlyNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        //показывает/прячет элементы если активирован/деактевации фильтр по дате отправки/готовности
        private void dateC1_CheckedChanged(object sender, EventArgs e)
        {
            if (dateC1.Checked == true)
            {
                if (dateCheck.SelectedIndex != 0)
                {
                    dateC2.Show();
                    dateMinOrMax.Show();
                    dateWhere2.Show();
                }
            }
            else
            {
                dateC2.Hide();
                dateC2.Checked = false;
            }
            if (change == false)
                fillDAtaGrid();
        }

        //показывает/прячет элементы если активирован/деактевации фильтр по дате создания
        private void creatingDateC1_CheckedChanged(object sender, EventArgs e)
        {
            if (creatingDateC1.Checked == true)
            {
                if (creatingCheck.SelectedIndex != 0)
                {
                    creatingDateC2.Show();
                    creatingDateMinOrMax.Show();
                    creatingDateWhere2.Show();
                }
            }
            else
            {
                creatingDateC2.Hide();
                creatingDateMinOrMax.Hide();
                creatingDateWhere2.Hide();
                creatingDateC2.Checked = false;
            }
            if (change == false)
                fillDAtaGrid();
        }
    }
}
