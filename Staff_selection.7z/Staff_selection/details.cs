﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Drawing.Printing;

namespace Staff_selection
{
    public partial class details : Form
    {
        private delete del = new delete();
        public string id;
        public string table;
        public bool delbool = false;
        public details()
        {
            InitializeComponent();
        }

        //заполняет форму значениями из базы данных
        private void details_Shown(object sender, EventArgs e)
        {
            if (table == "resume")
            {
                nameL.Text = "Имя";
                MoneyL.Text = "Минимальная зарплата";
                dateL.Text = "Готовность";
            }
            else
            {
                panel1.Location = new Point(0,265);
                this.MinimumSize = new System.Drawing.Size(390, 500);
                this.MaximumSize = new System.Drawing.Size(390, 500);
            }
          
            SqlConnection con = new SqlConnection();
            SqlDataAdapter da;
            DataSet ds;

            con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
            con.Open(); //подключение к базе данных
            da = new SqlDataAdapter("select * from " + table + " where id="+id, con); //вывод всей информации из базы для дальнейшей работы с ней
            ds = new DataSet();
            da.Fill(ds, "0"); //перемещение инофрмацции из базы dataset для работы с ней
            DataTable dt = ds.Tables[0];
            con.Close();

            //заполнение формы
            positoin.Text = dt.Rows[0][1].ToString();
            for (int i = 0; i < 10; i++)
                creatingDate.Text += dt.Rows[0][2].ToString()[i];
            money.Text = dt.Rows[0][3].ToString()+" "+ dt.Rows[0][4].ToString();
            for (int i=0; i<10; i++)
                date.Text += dt.Rows[0][5].ToString()[i];
            name.Text = dt.Rows[0][6].ToString();
            inf.Text = dt.Rows[0][7].ToString();
            tel.Text = dt.Rows[0][8].ToString();
            mail.Text = dt.Rows[0][9].ToString();
            if (dt.Rows[0][10].ToString() == "True")
            {
                urgently.Show();
            }
            if (table=="resume")
            {
                for (int i = 0; i < 10; i++)
                    birthDate.Text += dt.Rows[0][11].ToString()[i];
                if (dt.Rows[0][12].ToString() == "1")
                    viseUSA.Text = "Есть";
                else
                    viseUSA.Text = "Нет";
                if (dt.Rows[0][13].ToString() == "1")
                    viseEU.Text = "Есть";
                else
                    viseEU.Text = "Нет";
                english.Text= birthDate.Text = dt.Rows[0][14].ToString();
            }
            if (table=="vacancies")
            {
               flag.Text = dt.Rows[0][11].ToString();
               duration.Text = dt.Rows[0][12].ToString() + " месяцев";
            }

        }

        //разблокирует главное меню если детали закрыты
        private void details_FormClosing(object sender, FormClosingEventArgs e)
        {
            del.Close();
            Form main = Application.OpenForms["main_menu"];
            main.Enabled=true;
        }

        //закрывает детали
        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //вызывает окно подтвержения удаления
        private void delete_Click(object sender, EventArgs e)
        {
            del.Show();
            this.Enabled = false;
        }

        //после закрытия окна подтверждения удаление, если было выбрано "Да" то удаляет текущую вакансию или резюме
        private void details_EnabledChanged(object sender, EventArgs e)
        {
            if (this.Enabled == true)
            {
                if (del.del == true)
                {
                    using (SqlConnection con = new SqlConnection("server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"))
                    {
                        con.Open();
                        using (SqlCommand command = new SqlCommand("DELETE FROM " + table + " WHERE Id = " + id, con))
                        {
                            command.ExecuteNonQuery();
                        }
                        con.Close();
                    }
                    this.Close();
                }
                del.Hide();
            }
        }

        //открывает создает окно для написание сообщения
        private void messege_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            sendMail send = new sendMail();
            send.clientAdress = mail.Text;
            send.Show();
        }

        //создает pdf-отчет резюме или вакансии
        private void report_Click(object sender, EventArgs e)
        {     
            if (table=="vacancies")
            {
                FileStream fs = new FileStream("Вакансия "+ name.Text+ ".pdf", FileMode.Create, FileAccess.Write, FileShare.None);
                Document doc = new Document();
                BaseFont bf = BaseFont.CreateFont("C:\\Windows\\Fonts\\arial.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
                iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 15, iTextSharp.text.Font.NORMAL);
                PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Вакансия", font));
                PdfContentByte cb = writer.DirectContent;   
                cb.SetColorFill(BaseColor.DARK_GRAY);
                cb.SetFontAndSize(bf, 10);
                cb.BeginText();
                string text = "Работодатель: "+name.Text;
                cb.ShowTextAligned(0, text, 15, 755, 0);
                cb.EndText();
                cb.BeginText();
                text = "Должность: "+ positoin.Text;
                cb.ShowTextAligned(0, text, 15, 740, 0);
                cb.EndText();
                cb.BeginText();
                text = "Дата Создания: " + creatingDate.Text + " на " + duration.Text;
                cb.ShowTextAligned(0, text, 15, 725, 0);
                cb.EndText();
                cb.BeginText();
                text = "Зарплата: " + money.Text;
                cb.ShowTextAligned(0, text, 15, 710, 0);
                cb.EndText();
                cb.BeginText();
                text = "Телефон: " + tel.Text;
                cb.ShowTextAligned(0, text, 15, 695, 0);
                cb.EndText();
                cb.BeginText();
                text = "Почта: " + mail.Text;
                cb.ShowTextAligned(0, text, 15, 680, 0);
                cb.EndText();
                cb.BeginText();
                text = "Дата отправки: " + date.Text;
                cb.ShowTextAligned(0, text, 15, 665, 0);
                cb.EndText();
                cb.BeginText();
                text = "Флаг судна: " + flag.Text;
                cb.ShowTextAligned(0, text, 15, 650, 0);
                cb.EndText();
                if (inf.Text != "")
                {
                    cb.BeginText();
                    text = "Дополнительная информация: ";
                    cb.ShowTextAligned(0, text, 35, 635, 0);
                    cb.EndText();
                    cb.BeginText();
                    text = inf.Text;
                    cb.ShowTextAligned(0, text, 15, 620, 0);
                    cb.EndText();
                }
                doc.Close();
                writer.Close();
                fs.Close();
                MessageBox.Show("Отчет создан");
            }
            if (table=="resume")
            {
                FileStream fs = new FileStream("Вакансия " + name.Text + ".pdf", FileMode.Create, FileAccess.Write, FileShare.None);
                Document doc = new Document();
                BaseFont bf = BaseFont.CreateFont("C:\\Windows\\Fonts\\arial.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
                iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 15, iTextSharp.text.Font.NORMAL);
                PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                doc.Open();
                doc.Add(new Paragraph("Резюме", font));
                PdfContentByte cb = writer.DirectContent;
                cb.SetColorFill(BaseColor.DARK_GRAY);
                cb.SetFontAndSize(bf, 10);
                cb.BeginText();
                string text = "ФИО: " + name.Text;
                cb.ShowTextAligned(0, text, 15, 755, 0);
                cb.EndText();
                cb.BeginText();
                text = "Должность: " + positoin.Text;
                cb.ShowTextAligned(0, text, 15, 740, 0);
                cb.EndText();
                cb.BeginText();
                text = "Дата Создания: " + creatingDate.Text;
                cb.ShowTextAligned(0, text, 15, 725, 0);
                cb.EndText();
                cb.BeginText();
                text = "Минимальная зарплата: " + money.Text;
                cb.ShowTextAligned(0, text, 15, 710, 0);
                cb.EndText();
                cb.BeginText();
                text = "Телефон: " + tel.Text;
                cb.ShowTextAligned(0, text, 15, 695, 0);
                cb.EndText();
                cb.BeginText();
                text = "Почта: " + mail.Text;
                cb.ShowTextAligned(0, text, 15, 680, 0);
                cb.EndText();
                cb.BeginText();
                text = "Готовность: " + date.Text;
                cb.ShowTextAligned(0, text, 15, 665, 0);
                cb.EndText();
                cb.BeginText();
                text = "Дата рождения: " + birthDate.Text;
                cb.ShowTextAligned(0, text, 15, 650, 0);
                cb.EndText();
                cb.BeginText();
                text = "Виза США: " + viseUSA.Text;
                cb.ShowTextAligned(0, text, 15, 635, 0);
                cb.EndText();
                cb.BeginText();
                text = "Виза шенген: " + viseEU.Text;
                cb.ShowTextAligned(0, text, 15, 620, 0);
                cb.EndText();
                cb.BeginText();
                text = "Знание английского: " + english.Text;
                cb.ShowTextAligned(0, text, 15, 615, 0);
                cb.EndText();
                if (inf.Text != "")
                {
                    cb.BeginText();
                    text = "Дополнительная информация: ";
                    cb.ShowTextAligned(0, text, 35, 600, 0);
                    cb.EndText();
                    cb.BeginText();
                    text = inf.Text;
                    cb.ShowTextAligned(0, text, 15, 585, 0);
                    cb.EndText();
                }
                doc.Close();
                writer.Close();
                fs.Close();
                MessageBox.Show("Отчет создан");
            }
        }

        //создает окно акчати
        private void print_Click(object sender, EventArgs e)
        {
            Printing Printing = new Printing(this);
            Printing.Show();
            this.Enabled = false;
        }
    }
}
