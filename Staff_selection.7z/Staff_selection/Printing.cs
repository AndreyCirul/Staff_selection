﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace Staff_selection
{
    public partial class Printing : Form
    {
        private details det;
        public Printing(details det)
        {
            InitializeComponent();
            this.det = det;
        }
        
        //создает список принтеров которые подключены к компьютеру
        private void Printing_Shown(object sender, EventArgs e)
        {

            try
            {
                String pkInstalledPrinters;
                for (int i = 0; i < PrinterSettings.InstalledPrinters.Count; i++)
                {
                    pkInstalledPrinters = PrinterSettings.InstalledPrinters[i];
                    printers.Items.Add(pkInstalledPrinters);
                    printers.SelectedIndex = 0;
                }
            }
            catch
            {
                MessageBox.Show("Невозможно обноружить принтеры. Печать будет недоступна.");
            }
        }

        //если нажата кнопка назад то закрывает окно
        private void Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //вызывает функцию печатания после чего закрывает окно
        private void OK_Click(object sender, EventArgs e)
        {
            printing();
            this.Close();
        }

        //разблокирует окно деталей если окно было закрыто
        private void Printing_FormClosing(object sender, FormClosingEventArgs e)
        {
            det.Enabled=true;
        }

        //печатает отчет
        public void printing()
        {
            if (printers.SelectedItem.ToString() != "")
            {
                PrintDocument pd = new PrintDocument();
                PrinterSettings ps = new PrinterSettings();
                ps.PrinterName = printers.SelectedItem.ToString();
                pd.PrinterSettings = ps;
                pd.PrintPage += new PrintPageEventHandler(this.pd_PrintPage);
                pd.Print();
            }
        }

        //составляет содержания отчета для распечатки
        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            if (det.table == "vacancies")
            {
                Font printFont = new Font("Arial", 17);
                ev.Graphics.DrawString("Вакансия", printFont, Brushes.Black, 50, 10, new StringFormat());
                printFont = new Font("Arial", 10);
                ev.Graphics.DrawString("Работодатель: "+det.name.Text, printFont, Brushes.Black, 20, 35, new StringFormat());
                ev.Graphics.DrawString("Должность: " + det.positoin.Text, printFont, Brushes.Black, 20, 50, new StringFormat());
                ev.Graphics.DrawString("Дата создания заявки: " + det.creatingDate.Text, printFont, Brushes.Black, 20, 65, new StringFormat());
                ev.Graphics.DrawString("Зарплата: " + det.money.Text, printFont, Brushes.Black, 20, 80, new StringFormat());
                ev.Graphics.DrawString("Дата отправки: " + det.date.Text, printFont, Brushes.Black, 20, 95, new StringFormat());
                ev.Graphics.DrawString("Длительность: " + det.duration.Text+" месяцев", printFont, Brushes.Black, 20, 110, new StringFormat());
                ev.Graphics.DrawString("Флаг судна: " + det.flag.Text, printFont, Brushes.Black, 20, 125, new StringFormat());
                ev.Graphics.DrawString("Телефон: " + det.tel.Text, printFont, Brushes.Black, 20, 140, new StringFormat());
                ev.Graphics.DrawString("Почта: " + det.mail.Text, printFont, Brushes.Black, 20, 155, new StringFormat());
                ev.Graphics.DrawString("Телефон: " + det.viseEU.Text, printFont, Brushes.Black, 20, 140, new StringFormat());
                ev.Graphics.DrawString("Дополнительная информация: " + det.inf.Text, printFont, Brushes.Black, 20, 155, new StringFormat());
            }
            if (det.table=="resume")
            {
                Font printFont = new Font("Arial", 17);
                ev.Graphics.DrawString("Вакансия", printFont, Brushes.Black, 50, 10, new StringFormat());
                printFont = new Font("Arial", 10);
                ev.Graphics.DrawString("ФИО: " + det.name.Text, printFont, Brushes.Black, 20, 35, new StringFormat());
                ev.Graphics.DrawString("Должность: " + det.positoin.Text, printFont, Brushes.Black, 20, 50, new StringFormat());
                ev.Graphics.DrawString("Дата создания заявки: " + det.creatingDate.Text, printFont, Brushes.Black, 20, 65, new StringFormat());
                ev.Graphics.DrawString("Минимальная зарплата: " + det.money.Text, printFont, Brushes.Black, 20, 80, new StringFormat());
                ev.Graphics.DrawString("Готовность: " + det.date.Text, printFont, Brushes.Black, 20, 95, new StringFormat());
                ev.Graphics.DrawString("Дата рождения: " + det.birthDate.Text, printFont, Brushes.Black, 20, 110, new StringFormat());
                ev.Graphics.DrawString("Виза США: " + det.viseUSA.Text, printFont, Brushes.Black, 20, 125, new StringFormat());
                ev.Graphics.DrawString("Виза шенген: " + det.viseEU.Text, printFont, Brushes.Black, 20, 140, new StringFormat());
                ev.Graphics.DrawString("Знание английского: " + det.english.Text, printFont, Brushes.Black, 20, 155, new StringFormat());
                ev.Graphics.DrawString("Телефон: " + det.viseEU.Text, printFont, Brushes.Black, 20, 170, new StringFormat());
                ev.Graphics.DrawString("Почта: " + det.english.Text, printFont, Brushes.Black, 20, 155, new StringFormat());
                ev.Graphics.DrawString("Дополнительная информация: " + det.inf.Text, printFont, Brushes.Black, 20, 140, new StringFormat());
            }
        }
    }
}
