﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Staff_selection
{
    public partial class delete : Form
    {
        public bool delClick;
        public bool del;
        public string table="";
        public delete()
        {
            InitializeComponent();
        }

        //Если нажата кнопка Нет то разблокирует окно деталей
        private void NO_Click(object sender, EventArgs e)
        {
            del = false;
            Form det = Application.OpenForms["details"];
            det.Enabled = true;
        }

        //если нажата кнопка Да то разблокирует окно деталей
        private void YES_Click(object sender, EventArgs e)
        {
            del = true;
            Form det = Application.OpenForms["details"];
            det.Enabled = true;
        }

        //изменяет текс в окне удаления в зависимости от таблицы из которой происходит удаление
        private void delete_Shown(object sender, EventArgs e)
        {
            if (table=="resume")
                message.Text += "резюме?";
            if (table == "vacancies")
                message.Text += "вакансию?";
        }
    }
}
