﻿namespace Staff_selection
{
    partial class sendMail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.from = new System.Windows.Forms.TextBox();
            this.send = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.clientL = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.message = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.errorMes = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sunbect = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // from
            // 
            this.from.Location = new System.Drawing.Point(125, 35);
            this.from.Name = "from";
            this.from.Size = new System.Drawing.Size(85, 20);
            this.from.TabIndex = 0;
            // 
            // send
            // 
            this.send.Location = new System.Drawing.Point(12, 347);
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(75, 23);
            this.send.TabIndex = 1;
            this.send.Text = "Отправить";
            this.send.UseVisualStyleBackColor = true;
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(197, 347);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 2;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // clientL
            // 
            this.clientL.AutoSize = true;
            this.clientL.Location = new System.Drawing.Point(122, 13);
            this.clientL.Name = "clientL";
            this.clientL.Size = new System.Drawing.Size(0, 13);
            this.clientL.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Адресс получателя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(104, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Сообщение";
            // 
            // message
            // 
            this.message.Location = new System.Drawing.Point(12, 147);
            this.message.Multiline = true;
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(260, 152);
            this.message.TabIndex = 6;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(125, 61);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(147, 20);
            this.password.TabIndex = 7;
            this.password.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ваша почта";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Пароль от почты";
            // 
            // errorMes
            // 
            this.errorMes.AutoSize = true;
            this.errorMes.ForeColor = System.Drawing.Color.Red;
            this.errorMes.Location = new System.Drawing.Point(15, 311);
            this.errorMes.Name = "errorMes";
            this.errorMes.Size = new System.Drawing.Size(0, 13);
            this.errorMes.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Тема ";
            // 
            // sunbect
            // 
            this.sunbect.Location = new System.Drawing.Point(125, 88);
            this.sunbect.Name = "sunbect";
            this.sunbect.Size = new System.Drawing.Size(147, 20);
            this.sunbect.TabIndex = 12;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "@gmail.com",
            "@mail.ru",
            "@yandex.ru"});
            this.comboBox1.Location = new System.Drawing.Point(216, 34);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(56, 21);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // sendMail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 382);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.sunbect);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.errorMes);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.password);
            this.Controls.Add(this.message);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.clientL);
            this.Controls.Add(this.back);
            this.Controls.Add(this.send);
            this.Controls.Add(this.from);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(300, 420);
            this.MinimumSize = new System.Drawing.Size(300, 420);
            this.Name = "sendMail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Связаться";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.sendMail_FormClosing);
            this.Shown += new System.EventHandler(this.sendMail_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox from;
        private System.Windows.Forms.Button send;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label clientL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox message;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label errorMes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox sunbect;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}