﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;

namespace Staff_selection
{
    public partial class login : Form
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private int usersId;

        public login()
        {
            InitializeComponent();
        }

        //если имя и пароль совпадают с хранящимися в базе данных то создает окно главного меню
        private void log_but_Click(object sender, EventArgs e)
        {
            try
            {
                if (log.Text != "")//проверка на введение пользователем логина
                {
                    SqlConnection con = new SqlConnection();
                    SqlDataAdapter da;
                    DataSet ds;
                    bool correct = false;
                    con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                    con.Open(); //подключение к базе данных
                    da = new SqlDataAdapter("select * from users where логин=\'" + log.Text + "\'", con); //вывод всей информации из базы для дальнейшей работы с ней
                    ds = new DataSet();
                    da.Fill(ds, "0"); //перемещение инофрмацции из базы dataset для работы с ней
                    if (ds.Tables[0].Rows.Count == 0)//проверка на существование пользователя
                        errorMes.Text = "Пользователь не существует";
                    else
                    {
                        if (pass.Text == "")//проверка на введение пользователем пароля
                        {
                            errorMes.Text = "Введите пароль";
                        }
                        else
                        {
                            if (EncryptString(pass.Text, "p@55w0rd") == ds.Tables[0].Rows[0][2].ToString())//проверка на правильность пароля
                            {
                                usersId = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                                correct = true;
                                errorMes.Text = "";
                            }
                            else
                                errorMes.Text = "Неправильный паролль";
                        }
                           
                    }
                    con.Close(); //закрыть подключение к базе данных

                    if (correct)//переход в главное меню если все введено правильно
                    {
                        main_menu main = new main_menu();
                        main.Location = this.Location;
                        main.Show();
                        this.Hide();
                    }

                }
                else
                    errorMes.Text = "Введите логин";
            }
            catch (Exception msg)
            {

                MessageBox.Show(msg.ToString());
            }
        }

        //открывает окно регистрации
        private void regist_Click(object sender, EventArgs e)
        {
            register register = new register();
            register.Show();
            this.Hide();
        }

        //шифрует пароль для что бы сравнить его с хранящимся в базе данных
        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        //создает окно быстрого просмотра вакансий
        private void vacancies_Click(object sender, EventArgs e)
        {
            quick quick = new quick();
            quick.showing ="vacancies";
            quick.Text = "Быстрый просмотр вакансий";
            quick.Location = this.Location;
            quick.Show();
            this.Enabled = false;
        }

        //создает окно быстрого просмотра резюме
        private void resume_Click(object sender, EventArgs e)
        {
            quick quick = new quick();
            quick.showing = "resume";
            quick.Text = "Быстрый просмотр резюме";
            quick.Location = this.Location;
            quick.Show();
            this.Enabled = false;
        }
    }
}
