﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Staff_selection
{
    public partial class addNew : Form
    {
        public string table;

        public addNew()
        {
            InitializeComponent();
            moneyPer.SelectedIndex=0;
            english.SelectedIndex = 0;
            date.MinDate = DateTime.Today;
            birthDate.MaxDate = DateTime.Today;
        }

        //Закрывает окно создания новой вакансии или резюме
        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Если окно создания закрыто то разблокирует главное меню
        private void addNew_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form main = Application.OpenForms["main_menu"];
            main.Enabled = true;
        }

        //проверяет чтоб были введены только числа
        private void onlyNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        //проверяет что емейл введен верно 
        private void mail_TextChanged(object sender, EventArgs e)
        {
            string pattern = @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$";
            Regex r = new Regex(pattern, RegexOptions.IgnoreCase);
            if (!r.Match(mail.Text).Success)
                errorMes.Text = "Эммейл введен неправильно";
            else
                errorMes.Text = "";
        }

        //проверяет что все поля заполнены и добовляет новою вакансию или резюме в таблицу 
        private void create_Click(object sender, EventArgs e)
        {
            if (errorMes.Text == "Не все поля заполнены или не заполнены верно")
                errorMes.Text = "";
            //проверка на заполненость полей
            if (errorMes.Text=="")
            { 
                bool error = false;
                if (name.Text == "")
            {
                error = true;
                nameL.ForeColor = Color.Red;
            }
            else
                nameL.ForeColor = Color.Black;
            if (position.Text == "")
            {
                error = true;
                positionL.ForeColor = Color.Red;
            }
            else
               positionL.ForeColor = Color.Black;
            if (money.Text == "")
            {
                error = true;
                moneyL.ForeColor = Color.Red;
            }
            else
                moneyL.ForeColor = Color.Black;
            if (tel.Text == "")
            {
                error = true;
                telL.ForeColor = Color.Red;
            }
            else
                telL.ForeColor = Color.Black;
            if (mail.Text == "")
            {
                error = true;
                mailL.ForeColor = Color.Red;
            }
            else
                mailL.ForeColor = Color.Black;
                if (duration.Visible == true)
                {
                    if (duration.Text == "")
                    {
                        error = true;
                        durationL.ForeColor = Color.Red;
                    }
                    else
                        durationL.ForeColor = Color.Black;
                }
                if (flagP.Visible == true)
                {
                    if (flag.Text == "")
                    {
                        error = true;
                        flagL.ForeColor = Color.Red;
                    }
                    else
                        flagL.ForeColor = Color.Black;
                }

                if (error)
                {
                    errorMes.Text = "Не все поля заполнены или не заполнены верно";
                }
                else
                {
                    errorMes.Text = "";

                    SqlConnection con = new SqlConnection();
                    SqlCommandBuilder cb;
                    SqlDataAdapter da;
                    DataSet ds;
                    int newId=0;

                    //поиск свободных строк в базе по Id
                    con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                    con.Open(); //подключение к базе данных
                    da = new SqlDataAdapter("select Id from " + table, con); //вывод списка Id
                    ds = new DataSet();
                    da.Fill(ds, "0");
                    //поиск пустого Id
                    for (int i=0;i<ds.Tables[0].Rows.Count;i++)
                    {
                        if ((i+1).ToString()!=ds.Tables[0].Rows[i][0].ToString())
                        {
                            //если Id не заполнен то он сохраняеться в переменную и поиск прерывается
                            newId = i + 1;
                            break;
                        }
                    }
                    con.Close();
                    ds.Clear();

                    int rowCount;
                    try
                    {
                        con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                        con.Open(); //подключение к базе данных
                        da = new SqlDataAdapter("select * from " + table, con); //вывод всей информации из базы для дальнейшей работы с ней
                        ds = new DataSet();
                        da.Fill(ds, "0"); //перемещение инофрмацции из базы dataset для работы с ней
                        DataTable dt = ds.Tables[0];
                        rowCount = dt.Rows.Count;
                        //если не было найдено пустого Id то добовляеться новый
                        if (newId!=0)
                            dt.Rows.Add(newId);
                        else
                            dt.Rows.Add(rowCount + 1);

                        //Заполнение таблицы введеными пользователем значениями
                        dt.Rows[rowCount][1] = position.Text;
                        dt.Rows[rowCount][2] = DateTime.Today;
                        dt.Rows[rowCount][3] = money.Text;
                        dt.Rows[rowCount][4] = moneyPer.SelectedItem.ToString();
                        dt.Rows[rowCount][5] = date.Value;
                        dt.Rows[rowCount][6] = name.Text;
                        dt.Rows[rowCount][7] = inf.Text;
                        dt.Rows[rowCount][8] = tel.Text;
                        dt.Rows[rowCount][9] = mail.Text;
                        if (urgently.Checked == true)
                             dt.Rows[rowCount][10] = 1;
                        else
                             dt.Rows[rowCount][10] = 0;
                        if (table=="resume")
                        {
                            dt.Rows[rowCount][11] = birthDate.Value;
                            if (viseUSA.Checked == true)
                                dt.Rows[rowCount][12] = 1;
                            else
                                dt.Rows[rowCount][12] = 0;
                            if (viseEU.Checked == true)
                                dt.Rows[rowCount][13] = 1;
                            else
                                dt.Rows[rowCount][13] = 0;
                            dt.Rows[rowCount][14] = english.SelectedItem.ToString();
                        }
                        if (table=="vacancies")
                        {
                            dt.Rows[rowCount][11] = flag.Text;
                            dt.Rows[rowCount][12] = duration.Text;
                        }

                        cb = new SqlCommandBuilder(da);
                        da.Update(dt);

                        con.Close();

                        this.Close();
                    }
                    catch
                    {
                        MessageBox.Show("Проблемы с соеденинием с базой данных");
                    }
                }
            }

        }

        //выводит совет при выборе даты
        private void birthDate_Enter(object sender, EventArgs e)
        {
            errorMes.ForeColor = Color.Green;
            errorMes.Text = "Для болле быстрого и удобного измения месяца и \nгода нажмите на год (нажимать можно несколько раз)";
        }

        //убирает совет после завершения выбора даты
        private void birthDate_Leave(object sender, EventArgs e)
        {
            errorMes.ForeColor = Color.Red;
            errorMes.Text = "";
        }
    }
}
