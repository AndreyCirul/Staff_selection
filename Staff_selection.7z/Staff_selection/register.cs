﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;

namespace Staff_selection
{

    public partial class register : Form
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;

        public register()
        {
            InitializeComponent();
            ToolTip t = new ToolTip();
            t.SetToolTip(label1, "Поле обязательно к заполнению");
            t.SetToolTip(label2, "Поле обязательно к заполнению");
            t.SetToolTip(log, "Поле обязательно к заполнению");
            t.SetToolTip(pass, "Поле обязательно к заполнению");
        }

        //возвращение к входу
        private void back_Click(object sender, EventArgs e)
        {
            Form login = Application.OpenForms["login"];
            login.Show();
            this.Close();
        }

        //добавление нового пользователя в баззу данных
        private void regist_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                SqlDataAdapter da;
                DataSet ds;
                SqlCommandBuilder cb;
                int rowsCount;
                bool logExsist = false;
                bool created = false;

                con.ConnectionString = "server=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|staff_selection_db.mdf;Integrated Security=True"; //параметры подключение к базе данных
                con.Open(); //подключение к базе данных

                da = new SqlDataAdapter("select * from users", con); //вывод всей информации из базы для дальнейшей работы с ней
                ds = new DataSet();
                da.Fill(ds, "0"); //перемещение инофрмацции из базы dataset для работы с ней
                rowsCount = ds.Tables[0].Rows.Count;

                for (int i = 0; i < rowsCount; i++) //проверка на существует ли уже логин
                {
                    if (log.Text == ds.Tables[0].Rows[i][1].ToString())
                    {
                        logExsist = true;
                        break;
                    }
                }

                if (log.Text.Length != 0)
                {
                    if (!logExsist)
                    {

                        if (pass.Text.Length != 0)
                        {
                            //заполнение значений введеных пользователем в dataSet
                            ds.Tables[0].Rows.Add(rowsCount + 1);
                            ds.Tables[0].Rows[rowsCount][1] = log.Text;
                            ds.Tables[0].Rows[rowsCount][2] = EncryptString(pass.Text, "p@55w0rd");
                            //обновление базы данных
                            cb = new SqlCommandBuilder(da);
                            da.Update(ds, "0");
                            created = true;
                        }
                        else
                        {
                            errorMes.Text = "Введите пароль";
                        }
                    }
                    else
                    {
                        errorMes.Text = "Такой логин уже существует";
                    }
                }
                else
                {
                    errorMes.Text = "Введите логин";
                }

                con.Close(); //закрыть соединение с сервером 

                if (created)//переход в главное меню если аакаунт был создан
                {
                    main_menu main = new main_menu();
                    main.Location = this.Location;
                    main.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //возвращение к окну входа если окно регистрации будет закрыто
        private void register_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form login = Application.OpenForms["login"];
            login.Show();
        }

        //шифрует пароль
        public static string EncryptString(string plainText, string passPhrase) //функция шифрования для паролля 
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }
    }
}
