﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace Staff_selection
{
    public partial class sendMail : Form
    {
        private string smpt;
        private int port;
        public string clientAdress="";
        public sendMail()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 1;
        }

        //когда окно показываеться то адрес указаный в вакансии или резюме выводиться на экране в качестве адресса получателя
        private void sendMail_Shown(object sender, EventArgs e)
        {
            clientL.Text = clientAdress;
        }

        //отправляет сообщение
        private void send_Click(object sender, EventArgs e)
        {
            if (password.Text!="" && from.Text!="")
            {
                try
                {
                    errorMes.Text = "";
                    SmtpClient client = new SmtpClient(smpt, port);
                    client.Credentials = new NetworkCredential(from.Text + comboBox1.SelectedItem.ToString(), password.Text);
                    client.EnableSsl = true;
                    client.Send(from.Text + comboBox1.SelectedItem.ToString(), clientAdress, sunbect.Text, message.Text);
                    this.Close();
                }
                catch 
                {
                    errorMes.Text = "Сообщение не было отправильно \nПроверьте что данные введены правильно";
                }
            }
            else
            {

                if (from.Text == "")
                    errorMes.Text = "Введите адресс своей почты";
                else
                    if (password.Text=="")
                        errorMes.Text = "Введите пароль от почты";
            }
        }

        //если нажата кнопка назад, закрывает окно
        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //если окно закрывается то разблокирует окно деталей
        private void sendMail_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form det = Application.OpenForms["details"];
            det.Enabled = true;
        }

        //меняет порт и смт сервер в зависимости от почты
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString()=="@gmail.com")
            {
                smpt = "smtp.gmail.com";
                port = 587;
                errorMes.Text = "Внимание если на вашем аакаунте включена двойная \nаунтефикация то сообщение нельзя будет отправить";
            }
            if (comboBox1.SelectedItem.ToString() == "@mail.ru")
            {
                smpt = "smtp.mail.ru";
                port = 25;
                errorMes.Text = "";
            }
            if (comboBox1.SelectedItem.ToString() == "@yandex.ru")
            {
                smpt = "smtp.yandex.ru";
                port = 25;
                errorMes.Text = "";
            }

        }
    }
}
