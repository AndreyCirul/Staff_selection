﻿namespace Staff_selection
{
    partial class details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.delete = new System.Windows.Forms.Button();
            this.messege = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.print = new System.Windows.Forms.Button();
            this.report = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.inf = new System.Windows.Forms.RichTextBox();
            this.urgently = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dateL = new System.Windows.Forms.Label();
            this.nameL = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.creatingDateL = new System.Windows.Forms.Label();
            this.MoneyL = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.positoin = new System.Windows.Forms.Label();
            this.creatingDate = new System.Windows.Forms.Label();
            this.money = new System.Windows.Forms.Label();
            this.tel = new System.Windows.Forms.Label();
            this.mail = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.vacTable = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.duration = new System.Windows.Forms.Label();
            this.flag = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.resumeTable = new System.Windows.Forms.TableLayoutPanel();
            this.birthDate = new System.Windows.Forms.Label();
            this.viseUSA = new System.Windows.Forms.Label();
            this.viseEU = new System.Windows.Forms.Label();
            this.english = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.vacTable.SuspendLayout();
            this.resumeTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(9, 165);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(59, 23);
            this.delete.TabIndex = 0;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // messege
            // 
            this.messege.Location = new System.Drawing.Point(74, 165);
            this.messege.Name = "messege";
            this.messege.Size = new System.Drawing.Size(69, 23);
            this.messege.TabIndex = 1;
            this.messege.Text = "Связаться ";
            this.messege.UseVisualStyleBackColor = true;
            this.messege.Click += new System.EventHandler(this.messege_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(309, 165);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(59, 23);
            this.back.TabIndex = 2;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.back);
            this.panel1.Controls.Add(this.print);
            this.panel1.Controls.Add(this.report);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.messege);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.inf);
            this.panel1.Location = new System.Drawing.Point(0, 316);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(382, 195);
            this.panel1.TabIndex = 5;
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(149, 165);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(72, 23);
            this.print.TabIndex = 12;
            this.print.Text = "Печатать";
            this.print.UseVisualStyleBackColor = true;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // report
            // 
            this.report.Location = new System.Drawing.Point(227, 165);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(69, 23);
            this.report.TabIndex = 11;
            this.report.Text = "Отчет";
            this.report.UseVisualStyleBackColor = true;
            this.report.Click += new System.EventHandler(this.report_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Дополнительная информация";
            // 
            // inf
            // 
            this.inf.BackColor = System.Drawing.SystemColors.Control;
            this.inf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.inf.Location = new System.Drawing.Point(15, 26);
            this.inf.Name = "inf";
            this.inf.ReadOnly = true;
            this.inf.Size = new System.Drawing.Size(349, 133);
            this.inf.TabIndex = 0;
            this.inf.Text = "";
            // 
            // urgently
            // 
            this.urgently.AutoSize = true;
            this.urgently.Location = new System.Drawing.Point(161, 9);
            this.urgently.Name = "urgently";
            this.urgently.Size = new System.Drawing.Size(43, 13);
            this.urgently.TabIndex = 6;
            this.urgently.Text = "Срочно";
            this.urgently.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.dateL, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.nameL, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.creatingDateL, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.MoneyL, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.name, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.positoin, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.creatingDate, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.money, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tel, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.mail, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.date, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 25);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(352, 182);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // dateL
            // 
            this.dateL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateL.AutoSize = true;
            this.dateL.Location = new System.Drawing.Point(4, 162);
            this.dateL.Name = "dateL";
            this.dateL.Size = new System.Drawing.Size(83, 13);
            this.dateL.TabIndex = 4;
            this.dateL.Text = "Дата отправки";
            // 
            // nameL
            // 
            this.nameL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.nameL.AutoSize = true;
            this.nameL.Location = new System.Drawing.Point(4, 7);
            this.nameL.Name = "nameL";
            this.nameL.Size = new System.Drawing.Size(78, 13);
            this.nameL.TabIndex = 0;
            this.nameL.Text = "Работодатель";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Должность";
            // 
            // creatingDateL
            // 
            this.creatingDateL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.creatingDateL.AutoSize = true;
            this.creatingDateL.Location = new System.Drawing.Point(4, 59);
            this.creatingDateL.Name = "creatingDateL";
            this.creatingDateL.Size = new System.Drawing.Size(84, 13);
            this.creatingDateL.TabIndex = 2;
            this.creatingDateL.Text = "Дата создания";
            // 
            // MoneyL
            // 
            this.MoneyL.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MoneyL.AutoSize = true;
            this.MoneyL.Location = new System.Drawing.Point(4, 85);
            this.MoneyL.Name = "MoneyL";
            this.MoneyL.Size = new System.Drawing.Size(55, 13);
            this.MoneyL.TabIndex = 3;
            this.MoneyL.Text = "Зарплата";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Телефон";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Почта";
            // 
            // name
            // 
            this.name.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(179, 7);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(35, 13);
            this.name.TabIndex = 6;
            this.name.Text = "label6";
            // 
            // positoin
            // 
            this.positoin.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.positoin.AutoSize = true;
            this.positoin.Location = new System.Drawing.Point(179, 33);
            this.positoin.Name = "positoin";
            this.positoin.Size = new System.Drawing.Size(35, 13);
            this.positoin.TabIndex = 7;
            this.positoin.Text = "label6";
            // 
            // creatingDate
            // 
            this.creatingDate.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.creatingDate.AutoSize = true;
            this.creatingDate.Location = new System.Drawing.Point(179, 59);
            this.creatingDate.Name = "creatingDate";
            this.creatingDate.Size = new System.Drawing.Size(0, 13);
            this.creatingDate.TabIndex = 8;
            // 
            // money
            // 
            this.money.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.money.AutoSize = true;
            this.money.Location = new System.Drawing.Point(179, 85);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(35, 13);
            this.money.TabIndex = 9;
            this.money.Text = "label6";
            // 
            // tel
            // 
            this.tel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tel.AutoSize = true;
            this.tel.Location = new System.Drawing.Point(179, 111);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(35, 13);
            this.tel.TabIndex = 10;
            this.tel.Text = "label6";
            // 
            // mail
            // 
            this.mail.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.mail.AutoSize = true;
            this.mail.Location = new System.Drawing.Point(179, 137);
            this.mail.Name = "mail";
            this.mail.Size = new System.Drawing.Size(35, 13);
            this.mail.TabIndex = 11;
            this.mail.Text = "label6";
            // 
            // date
            // 
            this.date.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.date.AutoSize = true;
            this.date.Location = new System.Drawing.Point(179, 162);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(0, 13);
            this.date.TabIndex = 12;
            // 
            // vacTable
            // 
            this.vacTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.vacTable.ColumnCount = 2;
            this.vacTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.vacTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.vacTable.Controls.Add(this.label4, 0, 0);
            this.vacTable.Controls.Add(this.label5, 0, 1);
            this.vacTable.Controls.Add(this.duration, 1, 0);
            this.vacTable.Controls.Add(this.flag, 1, 1);
            this.vacTable.Location = new System.Drawing.Point(12, 206);
            this.vacTable.Name = "vacTable";
            this.vacTable.RowCount = 2;
            this.vacTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.vacTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.vacTable.Size = new System.Drawing.Size(352, 52);
            this.vacTable.TabIndex = 8;
            this.vacTable.UseWaitCursor = true;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Длительность";
            this.label4.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Флаг судна";
            this.label5.UseWaitCursor = true;
            // 
            // duration
            // 
            this.duration.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.duration.AutoSize = true;
            this.duration.Location = new System.Drawing.Point(179, 7);
            this.duration.Name = "duration";
            this.duration.Size = new System.Drawing.Size(35, 13);
            this.duration.TabIndex = 2;
            this.duration.Text = "label6";
            this.duration.UseWaitCursor = true;
            // 
            // flag
            // 
            this.flag.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.flag.AutoSize = true;
            this.flag.Location = new System.Drawing.Point(179, 33);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(35, 13);
            this.flag.TabIndex = 3;
            this.flag.Text = "label6";
            this.flag.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Дата рождения";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Виза США";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Виза шенген";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Знание английского";
            // 
            // resumeTable
            // 
            this.resumeTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.resumeTable.ColumnCount = 2;
            this.resumeTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.resumeTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.resumeTable.Controls.Add(this.label8, 0, 2);
            this.resumeTable.Controls.Add(this.label7, 0, 1);
            this.resumeTable.Controls.Add(this.label6, 0, 0);
            this.resumeTable.Controls.Add(this.label9, 0, 3);
            this.resumeTable.Controls.Add(this.birthDate, 1, 0);
            this.resumeTable.Controls.Add(this.viseUSA, 1, 1);
            this.resumeTable.Controls.Add(this.viseEU, 1, 2);
            this.resumeTable.Controls.Add(this.english, 1, 3);
            this.resumeTable.Location = new System.Drawing.Point(12, 206);
            this.resumeTable.Name = "resumeTable";
            this.resumeTable.RowCount = 4;
            this.resumeTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.resumeTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.resumeTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.resumeTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.resumeTable.Size = new System.Drawing.Size(352, 104);
            this.resumeTable.TabIndex = 9;
            this.resumeTable.Visible = false;
            // 
            // birthDate
            // 
            this.birthDate.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.birthDate.AutoSize = true;
            this.birthDate.Location = new System.Drawing.Point(179, 7);
            this.birthDate.Name = "birthDate";
            this.birthDate.Size = new System.Drawing.Size(0, 13);
            this.birthDate.TabIndex = 4;
            // 
            // viseUSA
            // 
            this.viseUSA.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.viseUSA.AutoSize = true;
            this.viseUSA.Location = new System.Drawing.Point(179, 33);
            this.viseUSA.Name = "viseUSA";
            this.viseUSA.Size = new System.Drawing.Size(41, 13);
            this.viseUSA.TabIndex = 5;
            this.viseUSA.Text = "label12";
            // 
            // viseEU
            // 
            this.viseEU.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.viseEU.AutoSize = true;
            this.viseEU.Location = new System.Drawing.Point(179, 59);
            this.viseEU.Name = "viseEU";
            this.viseEU.Size = new System.Drawing.Size(41, 13);
            this.viseEU.TabIndex = 6;
            this.viseEU.Text = "label13";
            // 
            // english
            // 
            this.english.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.english.AutoSize = true;
            this.english.Location = new System.Drawing.Point(179, 85);
            this.english.Name = "english";
            this.english.Size = new System.Drawing.Size(41, 13);
            this.english.TabIndex = 7;
            this.english.Text = "label14";
            // 
            // details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 512);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.urgently);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.resumeTable);
            this.Controls.Add(this.vacTable);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(396, 550);
            this.MinimumSize = new System.Drawing.Size(396, 550);
            this.Name = "details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Подробная информация";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.details_FormClosing);
            this.Shown += new System.EventHandler(this.details_Shown);
            this.EnabledChanged += new System.EventHandler(this.details_EnabledChanged);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.vacTable.ResumeLayout(false);
            this.vacTable.PerformLayout();
            this.resumeTable.ResumeLayout(false);
            this.resumeTable.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button messege;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label urgently;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label nameL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label MoneyL;
        private System.Windows.Forms.Label dateL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label creatingDate;
        public System.Windows.Forms.Label date;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label birthDate;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.TableLayoutPanel resumeTable;
        public System.Windows.Forms.TableLayoutPanel vacTable;
        private System.Windows.Forms.Button report;
        private System.Windows.Forms.Button print;
        public System.Windows.Forms.RichTextBox inf;
        public System.Windows.Forms.Label name;
        public System.Windows.Forms.Label positoin;
        public System.Windows.Forms.Label money;
        public System.Windows.Forms.Label tel;
        public System.Windows.Forms.Label mail;
        public System.Windows.Forms.Label duration;
        public System.Windows.Forms.Label flag;
        public System.Windows.Forms.Label viseEU;
        public System.Windows.Forms.Label english;
        public System.Windows.Forms.Label viseUSA;
        private System.Windows.Forms.Label creatingDateL;
    }
}