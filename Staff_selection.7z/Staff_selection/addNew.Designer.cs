﻿namespace Staff_selection
{
    partial class addNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.money = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.flag = new System.Windows.Forms.TextBox();
            this.tel = new System.Windows.Forms.TextBox();
            this.mail = new System.Windows.Forms.TextBox();
            this.moneyL = new System.Windows.Forms.Label();
            this.nameL = new System.Windows.Forms.Label();
            this.flagL = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.telL = new System.Windows.Forms.Label();
            this.mailL = new System.Windows.Forms.Label();
            this.create = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.urgently = new System.Windows.Forms.CheckBox();
            this.errorMes = new System.Windows.Forms.Label();
            this.inf = new System.Windows.Forms.TextBox();
            this.position = new System.Windows.Forms.TextBox();
            this.positionL = new System.Windows.Forms.Label();
            this.moneyPer = new System.Windows.Forms.ComboBox();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.dateL = new System.Windows.Forms.Label();
            this.birthDate = new System.Windows.Forms.DateTimePicker();
            this.birthDateL = new System.Windows.Forms.Label();
            this.viseUSA = new System.Windows.Forms.CheckBox();
            this.viseEU = new System.Windows.Forms.CheckBox();
            this.english = new System.Windows.Forms.ComboBox();
            this.englishL = new System.Windows.Forms.Label();
            this.duration = new System.Windows.Forms.TextBox();
            this.durationL = new System.Windows.Forms.Label();
            this.resume = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dateP = new System.Windows.Forms.Panel();
            this.month = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flagP = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.move = new System.Windows.Forms.Panel();
            this.resume.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.dateP.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.flagP.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.move.SuspendLayout();
            this.SuspendLayout();
            // 
            // money
            // 
            this.money.Location = new System.Drawing.Point(2, 20);
            this.money.Name = "money";
            this.money.Size = new System.Drawing.Size(114, 20);
            this.money.TabIndex = 2;
            this.money.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNum);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(4, 19);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(268, 20);
            this.name.TabIndex = 4;
            // 
            // flag
            // 
            this.flag.Location = new System.Drawing.Point(3, 25);
            this.flag.Name = "flag";
            this.flag.Size = new System.Drawing.Size(269, 20);
            this.flag.TabIndex = 5;
            // 
            // tel
            // 
            this.tel.Location = new System.Drawing.Point(4, 25);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(268, 20);
            this.tel.TabIndex = 7;
            this.tel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNum);
            // 
            // mail
            // 
            this.mail.Location = new System.Drawing.Point(5, 25);
            this.mail.Name = "mail";
            this.mail.Size = new System.Drawing.Size(267, 20);
            this.mail.TabIndex = 8;
            this.mail.TextChanged += new System.EventHandler(this.mail_TextChanged);
            // 
            // moneyL
            // 
            this.moneyL.AutoSize = true;
            this.moneyL.Location = new System.Drawing.Point(101, 4);
            this.moneyL.Name = "moneyL";
            this.moneyL.Size = new System.Drawing.Size(55, 13);
            this.moneyL.TabIndex = 13;
            this.moneyL.Text = "Зарплата";
            // 
            // nameL
            // 
            this.nameL.AutoSize = true;
            this.nameL.Location = new System.Drawing.Point(103, 3);
            this.nameL.Name = "nameL";
            this.nameL.Size = new System.Drawing.Size(78, 13);
            this.nameL.TabIndex = 15;
            this.nameL.Text = "Работодатель";
            // 
            // flagL
            // 
            this.flagL.AutoSize = true;
            this.flagL.Location = new System.Drawing.Point(102, 9);
            this.flagL.Name = "flagL";
            this.flagL.Size = new System.Drawing.Size(67, 13);
            this.flagL.TabIndex = 16;
            this.flagL.Text = "Флаг судна";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(59, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Дополнительная информация";
            // 
            // telL
            // 
            this.telL.AutoSize = true;
            this.telL.Location = new System.Drawing.Point(103, 9);
            this.telL.Name = "telL";
            this.telL.Size = new System.Drawing.Size(52, 13);
            this.telL.TabIndex = 18;
            this.telL.Text = "Телефон";
            // 
            // mailL
            // 
            this.mailL.AutoSize = true;
            this.mailL.Location = new System.Drawing.Point(103, 9);
            this.mailL.Name = "mailL";
            this.mailL.Size = new System.Drawing.Size(37, 13);
            this.mailL.TabIndex = 19;
            this.mailL.Text = "Почта";
            // 
            // create
            // 
            this.create.Location = new System.Drawing.Point(12, 361);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(75, 23);
            this.create.TabIndex = 20;
            this.create.Text = "Создать";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.create_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(217, 361);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 21;
            this.back.Text = "Отменить";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // urgently
            // 
            this.urgently.AutoSize = true;
            this.urgently.Location = new System.Drawing.Point(120, 314);
            this.urgently.Name = "urgently";
            this.urgently.Size = new System.Drawing.Size(62, 17);
            this.urgently.TabIndex = 22;
            this.urgently.Text = "Срочно";
            this.urgently.UseVisualStyleBackColor = true;
            // 
            // errorMes
            // 
            this.errorMes.AutoSize = true;
            this.errorMes.ForeColor = System.Drawing.Color.Red;
            this.errorMes.Location = new System.Drawing.Point(18, 335);
            this.errorMes.Name = "errorMes";
            this.errorMes.Size = new System.Drawing.Size(0, 13);
            this.errorMes.TabIndex = 23;
            this.errorMes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // inf
            // 
            this.inf.Location = new System.Drawing.Point(0, 25);
            this.inf.Multiline = true;
            this.inf.Name = "inf";
            this.inf.Size = new System.Drawing.Size(277, 166);
            this.inf.TabIndex = 24;
            // 
            // position
            // 
            this.position.Location = new System.Drawing.Point(2, 22);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(271, 20);
            this.position.TabIndex = 25;
            // 
            // positionL
            // 
            this.positionL.AutoSize = true;
            this.positionL.Location = new System.Drawing.Point(102, 6);
            this.positionL.Name = "positionL";
            this.positionL.Size = new System.Drawing.Size(65, 13);
            this.positionL.TabIndex = 26;
            this.positionL.Text = "Должность";
            // 
            // moneyPer
            // 
            this.moneyPer.FormattingEnabled = true;
            this.moneyPer.Items.AddRange(new object[] {
            "в день",
            "в месяц",
            "за рейс"});
            this.moneyPer.Location = new System.Drawing.Point(141, 19);
            this.moneyPer.Name = "moneyPer";
            this.moneyPer.Size = new System.Drawing.Size(130, 21);
            this.moneyPer.TabIndex = 27;
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(2, 19);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(138, 20);
            this.date.TabIndex = 28;
            this.date.Enter += new System.EventHandler(this.birthDate_Enter);
            this.date.Leave += new System.EventHandler(this.birthDate_Leave);
            // 
            // dateL
            // 
            this.dateL.AutoSize = true;
            this.dateL.Location = new System.Drawing.Point(7, 3);
            this.dateL.Name = "dateL";
            this.dateL.Size = new System.Drawing.Size(101, 13);
            this.dateL.TabIndex = 30;
            this.dateL.Text = "Дата отправления";
            // 
            // birthDate
            // 
            this.birthDate.Location = new System.Drawing.Point(2, 31);
            this.birthDate.MaxDate = new System.DateTime(2016, 11, 10, 0, 0, 0, 0);
            this.birthDate.Name = "birthDate";
            this.birthDate.Size = new System.Drawing.Size(269, 20);
            this.birthDate.TabIndex = 31;
            this.birthDate.Value = new System.DateTime(2016, 11, 10, 0, 0, 0, 0);
            this.birthDate.Enter += new System.EventHandler(this.birthDate_Enter);
            this.birthDate.Leave += new System.EventHandler(this.birthDate_Leave);
            // 
            // birthDateL
            // 
            this.birthDateL.AutoSize = true;
            this.birthDateL.Location = new System.Drawing.Point(102, 12);
            this.birthDateL.Name = "birthDateL";
            this.birthDateL.Size = new System.Drawing.Size(86, 13);
            this.birthDateL.TabIndex = 32;
            this.birthDateL.Text = "Дата рождения";
            // 
            // viseUSA
            // 
            this.viseUSA.AutoSize = true;
            this.viseUSA.Location = new System.Drawing.Point(10, 3);
            this.viseUSA.Name = "viseUSA";
            this.viseUSA.Size = new System.Drawing.Size(77, 17);
            this.viseUSA.TabIndex = 33;
            this.viseUSA.Text = "Виза США";
            this.viseUSA.UseVisualStyleBackColor = true;
            // 
            // viseEU
            // 
            this.viseEU.AutoSize = true;
            this.viseEU.Location = new System.Drawing.Point(183, 3);
            this.viseEU.Name = "viseEU";
            this.viseEU.Size = new System.Drawing.Size(91, 17);
            this.viseEU.TabIndex = 34;
            this.viseEU.Text = "Виза шенген";
            this.viseEU.UseVisualStyleBackColor = true;
            // 
            // english
            // 
            this.english.FormattingEnabled = true;
            this.english.Items.AddRange(new object[] {
            "Не очень",
            "Средне",
            "Хорошо"});
            this.english.Location = new System.Drawing.Point(2, 25);
            this.english.Name = "english";
            this.english.Size = new System.Drawing.Size(269, 21);
            this.english.TabIndex = 35;
            // 
            // englishL
            // 
            this.englishL.AutoSize = true;
            this.englishL.Location = new System.Drawing.Point(77, 9);
            this.englishL.Name = "englishL";
            this.englishL.Size = new System.Drawing.Size(111, 13);
            this.englishL.TabIndex = 36;
            this.englishL.Text = "Знание английского";
            // 
            // duration
            // 
            this.duration.Location = new System.Drawing.Point(146, 19);
            this.duration.Name = "duration";
            this.duration.Size = new System.Drawing.Size(73, 20);
            this.duration.TabIndex = 37;
            this.duration.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNum);
            // 
            // durationL
            // 
            this.durationL.AutoSize = true;
            this.durationL.Location = new System.Drawing.Point(154, 3);
            this.durationL.Name = "durationL";
            this.durationL.Size = new System.Drawing.Size(80, 13);
            this.durationL.TabIndex = 38;
            this.durationL.Text = "Длительность";
            // 
            // resume
            // 
            this.resume.Controls.Add(this.panel7);
            this.resume.Controls.Add(this.panel6);
            this.resume.Controls.Add(this.panel5);
            this.resume.Location = new System.Drawing.Point(15, 218);
            this.resume.Name = "resume";
            this.resume.Size = new System.Drawing.Size(277, 150);
            this.resume.TabIndex = 39;
            this.resume.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.viseUSA);
            this.panel7.Controls.Add(this.viseEU);
            this.panel7.Location = new System.Drawing.Point(0, 121);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(277, 26);
            this.panel7.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.english);
            this.panel6.Controls.Add(this.englishL);
            this.panel6.Location = new System.Drawing.Point(0, 62);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(277, 53);
            this.panel6.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.birthDate);
            this.panel5.Controls.Add(this.birthDateL);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(276, 56);
            this.panel5.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.name);
            this.panel1.Controls.Add(this.nameL);
            this.panel1.Location = new System.Drawing.Point(15, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(277, 45);
            this.panel1.TabIndex = 40;
            // 
            // dateP
            // 
            this.dateP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateP.Controls.Add(this.month);
            this.dateP.Controls.Add(this.date);
            this.dateP.Controls.Add(this.dateL);
            this.dateP.Controls.Add(this.durationL);
            this.dateP.Controls.Add(this.duration);
            this.dateP.Location = new System.Drawing.Point(15, 116);
            this.dateP.Name = "dateP";
            this.dateP.Size = new System.Drawing.Size(277, 44);
            this.dateP.TabIndex = 41;
            // 
            // month
            // 
            this.month.AutoSize = true;
            this.month.Location = new System.Drawing.Point(220, 22);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(52, 13);
            this.month.TabIndex = 39;
            this.month.Text = "Месяцев";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.moneyPer);
            this.panel3.Controls.Add(this.money);
            this.panel3.Controls.Add(this.moneyL);
            this.panel3.Location = new System.Drawing.Point(15, 166);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(277, 46);
            this.panel3.TabIndex = 42;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.position);
            this.panel4.Controls.Add(this.positionL);
            this.panel4.Location = new System.Drawing.Point(15, 62);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(277, 48);
            this.panel4.TabIndex = 43;
            // 
            // flagP
            // 
            this.flagP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flagP.Controls.Add(this.flag);
            this.flagP.Controls.Add(this.flagL);
            this.flagP.Location = new System.Drawing.Point(15, 218);
            this.flagP.Name = "flagP";
            this.flagP.Size = new System.Drawing.Size(277, 52);
            this.flagP.TabIndex = 44;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.tel);
            this.panel9.Controls.Add(this.telL);
            this.panel9.Location = new System.Drawing.Point(15, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(277, 50);
            this.panel9.TabIndex = 45;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.mail);
            this.panel10.Controls.Add(this.mailL);
            this.panel10.Location = new System.Drawing.Point(15, 61);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(277, 50);
            this.panel10.TabIndex = 46;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.inf);
            this.panel11.Controls.Add(this.label8);
            this.panel11.Location = new System.Drawing.Point(15, 117);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(277, 191);
            this.panel11.TabIndex = 47;
            // 
            // move
            // 
            this.move.Controls.Add(this.panel11);
            this.move.Controls.Add(this.panel9);
            this.move.Controls.Add(this.panel10);
            this.move.Controls.Add(this.urgently);
            this.move.Controls.Add(this.errorMes);
            this.move.Controls.Add(this.create);
            this.move.Controls.Add(this.back);
            this.move.Location = new System.Drawing.Point(0, 371);
            this.move.Name = "move";
            this.move.Size = new System.Drawing.Size(308, 393);
            this.move.TabIndex = 48;
            // 
            // addNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(334, 773);
            this.Controls.Add(this.flagP);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dateP);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.resume);
            this.Controls.Add(this.move);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(350, 811);
            this.MinimumSize = new System.Drawing.Size(345, 300);
            this.Name = "addNew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.addNew_FormClosing);
            this.resume.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.dateP.ResumeLayout(false);
            this.dateP.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.flagP.ResumeLayout(false);
            this.flagP.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.move.ResumeLayout(false);
            this.move.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox money;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox flag;
        private System.Windows.Forms.TextBox tel;
        private System.Windows.Forms.TextBox mail;
        private System.Windows.Forms.Label flagL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label telL;
        private System.Windows.Forms.Label mailL;
        private System.Windows.Forms.Button create;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.CheckBox urgently;
        public System.Windows.Forms.Label nameL;
        private System.Windows.Forms.Label errorMes;
        private System.Windows.Forms.TextBox inf;
        private System.Windows.Forms.TextBox position;
        private System.Windows.Forms.Label positionL;
        private System.Windows.Forms.ComboBox moneyPer;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.DateTimePicker birthDate;
        private System.Windows.Forms.Label birthDateL;
        private System.Windows.Forms.CheckBox viseUSA;
        private System.Windows.Forms.CheckBox viseEU;
        private System.Windows.Forms.ComboBox english;
        private System.Windows.Forms.Label englishL;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel dateP;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        public System.Windows.Forms.TextBox duration;
        public System.Windows.Forms.Label durationL;
        public System.Windows.Forms.Panel resume;
        public System.Windows.Forms.Label month;
        public System.Windows.Forms.Panel flagP;
        public System.Windows.Forms.Label moneyL;
        public System.Windows.Forms.Label dateL;
        public System.Windows.Forms.Panel move;
    }
}